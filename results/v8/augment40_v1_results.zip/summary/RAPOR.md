# BetaTour POPMUSIC 5+1 augmentation experiment

Complete: 40/40 new 10k/20k synthetic instances. Co-primary practical success: False.

Each six-slot augmented list preserves all five seed-specific POPMUSIC-5 entries in order.
The added sixth edge is absent from the entire undirected POPMUSIC-5 graph.
BetaTour, frequency and nearest controls share the five POP entries and sixth-edge alpha=500.
Percent difference = 100 * (BetaTour - control) / control; negative favours BetaTour.
Co-primary practical comparisons: BetaTour 5+1 versus continuous POPMUSIC-5 and POPMUSIC-6.
Success requires BOTH exact two-sided sign-test p-values < 0.05 and BetaTour-favouring direction (more wins than losses and negative mean difference).
This intersection-union decision requires no multiplicity correction across the two co-primary tests.
The three secondary overall sign tests (restarted POP5, nearest 5+1, frequency 5+1) receive Holm correction.
Subgroup rows are descriptive only. Bootstrap intervals describe mean paired differences, not sign-test p-values.
The six first tours are shared across the four restarted arms and are checked against continuous POP5; continuous POP6 can have different first tours.
Common first phase, arm-specific preparation and continuation count against each deadline. Drive writes and archive export do not.
This holdout covers synthetic uniform and clustered 10k/20k instances; it does not establish effects on TSPLIB or other distributions.
Incomplete data or POP5 first-trial mismatches suppress all inferential results.

```
 group                                  comparison class_of_comparison  instances  win  tie  loss  mean_delta_pct  median_delta_pct  ci95_low_pct  ci95_high_pct   sign_p  sign_p_holm_secondary
   all BetaTour 5+1 / continuous POP5 [co-primary]          co_primary         40   12    0    28        0.008588          0.004070      0.002224       0.014514 0.016589                    NaN
   all BetaTour 5+1 / continuous POP6 [co-primary]          co_primary         40    9    0    31        0.012508          0.005613      0.007283       0.018965 0.000680                    NaN
   all               BetaTour 5+1 / restarted POP5           secondary         40   22    0    18       -0.001242         -0.002321     -0.004878       0.002710 0.635828               0.635828
   all                  BetaTour 5+1 / nearest 5+1           secondary         40   32    0     8       -0.007316         -0.008020     -0.013742      -0.000342 0.000182               0.000546
   all                BetaTour 5+1 / frequency 5+1           secondary         40   28    0    12       -0.007707         -0.002587     -0.015649      -0.001921 0.016589               0.033178
clu10k BetaTour 5+1 / continuous POP5 [co-primary]          co_primary         12    7    0     5       -0.004393         -0.000633           NaN            NaN      NaN                    NaN
clu10k BetaTour 5+1 / continuous POP6 [co-primary]          co_primary         12    4    0     8        0.009604          0.002133           NaN            NaN      NaN                    NaN
clu10k               BetaTour 5+1 / restarted POP5           secondary         12    6    0     6        0.001774         -0.000126           NaN            NaN      NaN                    NaN
clu10k                  BetaTour 5+1 / nearest 5+1           secondary         12   10    0     2        0.000011         -0.007709           NaN            NaN      NaN                    NaN
clu10k                BetaTour 5+1 / frequency 5+1           secondary         12    9    0     3       -0.006102         -0.005112           NaN            NaN      NaN                    NaN
clu20k BetaTour 5+1 / continuous POP5 [co-primary]          co_primary          8    1    0     7        0.021168          0.012914           NaN            NaN      NaN                    NaN
clu20k BetaTour 5+1 / continuous POP6 [co-primary]          co_primary          8    1    0     7        0.020779          0.023375           NaN            NaN      NaN                    NaN
clu20k               BetaTour 5+1 / restarted POP5           secondary          8    4    0     4        0.005070          0.003244           NaN            NaN      NaN                    NaN
clu20k                  BetaTour 5+1 / nearest 5+1           secondary          8    6    0     2       -0.019979         -0.017870           NaN            NaN      NaN                    NaN
clu20k                BetaTour 5+1 / frequency 5+1           secondary          8    5    0     3       -0.020260         -0.003961           NaN            NaN      NaN                    NaN
uni10k BetaTour 5+1 / continuous POP5 [co-primary]          co_primary         12    4    0     8        0.002506          0.003735           NaN            NaN      NaN                    NaN
uni10k BetaTour 5+1 / continuous POP6 [co-primary]          co_primary         12    4    0     8        0.001723          0.002620           NaN            NaN      NaN                    NaN
uni10k               BetaTour 5+1 / restarted POP5           secondary         12    8    0     4       -0.006594         -0.003994           NaN            NaN      NaN                    NaN
uni10k                  BetaTour 5+1 / nearest 5+1           secondary         12   11    0     1       -0.010190         -0.011450           NaN            NaN      NaN                    NaN
uni10k                BetaTour 5+1 / frequency 5+1           secondary         12   10    0     2       -0.003817         -0.001947           NaN            NaN      NaN                    NaN
uni20k BetaTour 5+1 / continuous POP5 [co-primary]          co_primary          8    0    0     8        0.024604          0.024522           NaN            NaN      NaN                    NaN
uni20k BetaTour 5+1 / continuous POP6 [co-primary]          co_primary          8    0    0     8        0.024767          0.027418           NaN            NaN      NaN                    NaN
uni20k               BetaTour 5+1 / restarted POP5           secondary          8    4    0     4       -0.004051         -0.002175           NaN            NaN      NaN                    NaN
uni20k                  BetaTour 5+1 / nearest 5+1           secondary          8    5    0     3       -0.001336         -0.003639           NaN            NaN      NaN                    NaN
uni20k                BetaTour 5+1 / frequency 5+1           secondary          8    4    0     4       -0.003398         -0.003223           NaN            NaN      NaN                    NaN
```

Raw files: summary/per_instance.csv, summary/per_seed.csv, summary/candidate_diagnostics.csv.
The separate audit ZIP in Drive includes stages/phase1.npz and candidates/*.npz for candidate-list auditing.