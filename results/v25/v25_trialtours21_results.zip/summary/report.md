# BetaTour run v25 (pilot): atılan deneme turlarının birleştirilmesi

21/21 örnek tamamlandı.

Birincil kol: `trials_50` (altı LKH süreci bütçenin yarısında durur; her sürecin en iyi turu ve son 16 atılan deneme turu GA-EAX ile birleştirilir; toplam süre bütçeye eşittir). Karşılaştırma: `lkh6` (aynı altı süreç bütçenin sonuna kadar sürer; altısının en iyisi). Bütün zamanlar duvar saatidir.

## Bütçe sonunda karşılaştırmalar

| Grup | Karşılaştırma | Örnek | Kısa/eşit/uzun | Ortalama fark (%) | %95 GA | Ortanca (%) | p |
|---|---|---|---|---|---|---|---|
| all | P1: `trials_50` / `lkh6` | 21 | 21/0/0 | -0.0165 | -0.0198 ile -0.0130 | -0.0183 | 0.0000 |
| all | C1: `best6_50` / `lkh6` | 21 | 18/0/3 | -0.0200 | -0.0306 ile -0.0107 | -0.0120 | 0.0015 |
| all | C2: `trials_50` / `best6_50` | 21 | 16/1/4 | +0.0035 | -0.0049 ile +0.0137 | -0.0043 | 0.0118 |
| all | C3: `cascade` / `lkh6` | 21 | 13/0/8 | +0.0013 | -0.0090 ile +0.0131 | -0.0098 | 0.3833 |
| all | C4: `trials_50` / `cascade` | 21 | 16/0/5 | -0.0178 | -0.0297 ile -0.0074 | -0.0070 | 0.0266 |
| all | S1: `trials_33` / `lkh6` | 21 | 20/0/1 | -0.0149 | -0.0182 ile -0.0114 | -0.0149 | 0.0000 |
| all | S2: `best6_33` / `lkh6` | 21 | 16/0/5 | -0.0154 | -0.0266 ile -0.0058 | -0.0109 | 0.0266 |
| all | S3: `trials_67` / `lkh6` | 21 | 21/0/0 | -0.0137 | -0.0170 ile -0.0106 | -0.0104 | 0.0000 |
| all | S4: `best6_67` / `lkh6` | 21 | 21/0/0 | -0.0226 | -0.0335 ile -0.0132 | -0.0128 | 0.0000 |
| all | R1: `eax_scratch` / `lkh6` | 17 | 8/0/9 | +0.0116 | -0.0008 ile +0.0242 | +0.0041 | 1.0000 |
| all | R2: `trials_50` / `eax_scratch` | 17 | 15/0/2 | -0.0275 | -0.0407 ile -0.0147 | -0.0209 | 0.0023 |
| n10k | P1: `trials_50` / `lkh6` | 12 | 12/0/0 | -0.0139 | -0.0172 ile -0.0106 | -0.0144 | 0.0005 |
| n10k | C1: `best6_50` / `lkh6` | 12 | 9/0/3 | -0.0073 | -0.0117 ile -0.0030 | -0.0076 | 0.1460 |
| n10k | C2: `trials_50` / `best6_50` | 12 | 12/0/0 | -0.0066 | -0.0100 ile -0.0036 | -0.0050 | 0.0005 |
| n10k | C3: `cascade` / `lkh6` | 12 | 8/0/4 | -0.0070 | -0.0111 ile -0.0027 | -0.0101 | 0.3877 |
| n10k | C4: `trials_50` / `cascade` | 12 | 9/0/3 | -0.0069 | -0.0101 ile -0.0035 | -0.0069 | 0.1460 |
| n10k | S1: `trials_33` / `lkh6` | 12 | 12/0/0 | -0.0136 | -0.0168 ile -0.0100 | -0.0134 | 0.0005 |
| n10k | S2: `best6_33` / `lkh6` | 12 | 7/0/5 | -0.0023 | -0.0080 ile +0.0038 | -0.0034 | 0.7744 |
| n10k | S3: `trials_67` / `lkh6` | 12 | 12/0/0 | -0.0122 | -0.0154 ile -0.0092 | -0.0097 | 0.0005 |
| n10k | S4: `best6_67` / `lkh6` | 12 | 12/0/0 | -0.0100 | -0.0133 ile -0.0073 | -0.0084 | 0.0005 |
| n10k | R1: `eax_scratch` / `lkh6` | 12 | 4/0/8 | +0.0189 | +0.0050 ile +0.0326 | +0.0232 | 0.3877 |
| n10k | R2: `trials_50` / `eax_scratch` | 12 | 12/0/0 | -0.0328 | -0.0471 ile -0.0189 | -0.0346 | 0.0005 |
| n50k | P1: `trials_50` / `lkh6` | 4 | 4/0/0 | -0.0189 | -0.0255 ile -0.0125 | -0.0186 | 0.1250 |
| n50k | C1: `best6_50` / `lkh6` | 4 | 4/0/0 | -0.0662 | -0.0697 ile -0.0632 | -0.0653 | 0.1250 |
| n50k | C2: `trials_50` / `best6_50` | 4 | 0/0/4 | +0.0474 | +0.0399 ile +0.0529 | +0.0501 | 0.1250 |
| n50k | C3: `cascade` / `lkh6` | 4 | 0/0/4 | +0.0512 | +0.0391 ile +0.0659 | +0.0471 | 0.1250 |
| n50k | C4: `trials_50` / `cascade` | 4 | 4/0/0 | -0.0701 | -0.0794 ile -0.0622 | -0.0682 | 0.1250 |
| n50k | S1: `trials_33` / `lkh6` | 4 | 3/0/1 | -0.0134 | -0.0223 ile -0.0027 | -0.0152 | 0.6250 |
| n50k | S2: `best6_33` / `lkh6` | 4 | 4/0/0 | -0.0610 | -0.0681 ile -0.0523 | -0.0626 | 0.1250 |
| n50k | S3: `trials_67` / `lkh6` | 4 | 4/0/0 | -0.0123 | -0.0221 ile -0.0054 | -0.0095 | 0.1250 |
| n50k | S4: `best6_67` / `lkh6` | 4 | 4/0/0 | -0.0706 | -0.0754 ile -0.0652 | -0.0711 | 0.1250 |
| tsplib | P1: `trials_50` / `lkh6` | 5 | 5/0/0 | -0.0208 | -0.0294 ile -0.0106 | -0.0223 | 0.0625 |
| tsplib | C1: `best6_50` / `lkh6` | 5 | 5/0/0 | -0.0133 | -0.0202 ile -0.0063 | -0.0136 | 0.0625 |
| tsplib | C2: `trials_50` / `best6_50` | 5 | 4/1/0 | -0.0075 | -0.0126 ile -0.0023 | -0.0087 | 0.1250 |
| tsplib | C3: `cascade` / `lkh6` | 5 | 5/0/0 | -0.0187 | -0.0266 ile -0.0089 | -0.0180 | 0.0625 |
| tsplib | C4: `trials_50` / `cascade` | 5 | 3/0/2 | -0.0021 | -0.0096 ile +0.0042 | -0.0017 | 1.0000 |
| tsplib | S1: `trials_33` / `lkh6` | 5 | 5/0/0 | -0.0193 | -0.0270 ile -0.0106 | -0.0223 | 0.0625 |
| tsplib | S2: `best6_33` / `lkh6` | 5 | 5/0/0 | -0.0103 | -0.0156 ile -0.0045 | -0.0109 | 0.0625 |
| tsplib | S3: `trials_67` / `lkh6` | 5 | 5/0/0 | -0.0182 | -0.0236 ile -0.0103 | -0.0222 | 0.0625 |
| tsplib | S4: `best6_67` / `lkh6` | 5 | 5/0/0 | -0.0145 | -0.0205 ile -0.0077 | -0.0147 | 0.0625 |
| tsplib | R1: `eax_scratch` / `lkh6` | 5 | 4/0/1 | -0.0060 | -0.0255 ile +0.0135 | -0.0034 | 0.3750 |
| tsplib | R2: `trials_50` / `eax_scratch` | 5 | 3/0/2 | -0.0147 | -0.0401 ile +0.0055 | -0.0075 | 1.0000 |

## Optimumu bilinen örneklerde optimuma uzaklık (%)

| Örnek | Düğüm | Bütçe (s) | `lkh6` | `best6_50` | `trials_50` | `cascade` | `eax_scratch` |
|---|---|---|---|---|---|---|---|
| rl11849 | 11849 | 237 | 0.0409 | 0.0160 | 0.0160 | 0.0087 | 0.0000 |
| usa13509 | 13509 | 270 | 0.0039 | 0.0025 | 0.0010 | 0.0031 | 0.0005 |
| brd14051 | 14051 | 281 | 0.0215 | 0.0119 | 0.0019 | 0.0036 | 0.0094 |
| d15112 | 15112 | 302 | 0.0353 | 0.0184 | 0.0012 | 0.0174 | 0.0631 |
| d18512 | 18512 | 370 | 0.0248 | 0.0112 | 0.0025 | 0.0003 | 0.0234 |
| ortalama | | | 0.0253 | 0.0120 | 0.0045 | 0.0066 | 0.0193 |

## Mekanizma (birincil kol, sınıf ortalamaları)

| Sınıf | Örnek | Kesimde deneme/süreç | Birleşim kenarı/düğüm | Ortak kenar/düğüm | İkili ortak kenar payı | GA-EAX süresi (s) | Yakınsayan | LKH'nin son uzunluğuna ulaşma (bütçenin kesri) | Bilinen melezde tur sayısı |
|---|---|---|---|---|---|---|---|---|---|
| n10k | 12 | 124 | 1.464 | 0.616 | 0.920 | 45 | 10/12 | 0.60 (12/12 örnek) | 81 |
| n50k | 4 | 58 | 1.567 | 0.552 | 0.894 | 300 | 0/4 | 0.77 (4/4 örnek) | 94 |
| tsplib | 5 | 227 | 1.446 | 0.622 | 0.923 | 92 | 4/5 | 0.55 (5/5 örnek) | 100 |

## Karar kuralı (koşudan önce yazıldı)

- D1, küçük boyutta tekrar (n10k): `trials_50` / `lkh6` daha çok örnekte kısa ve p < 0,05: **evet** (12/0/0 (ilk kol kısa/eşit/uzun), ortalama %-0.0139 (%95 GA -0.0172 ile -0.0106), ortanca %-0.0144, işaret testi p = 0.0005).
- D2, kazanç boyutla büyüyor (n50k): bütün örneklerde kısa ve ortalama fark n10k sınıfındakinden büyük: **evet** (4/0/0 (ilk kol kısa/eşit/uzun), ortalama %-0.0189 (%95 GA -0.0255 ile -0.0125), ortanca %-0.0186, işaret testi p = 0.1250).
- D3, atılan turların katkısı (n10k): `trials_50` / `best6_50` daha çok örnekte kısa ve p < 0,05: **evet** (12/0/0 (ilk kol kısa/eşit/uzun), ortalama %-0.0066 (%95 GA -0.0100 ile -0.0036), ortanca %-0.0050, işaret testi p = 0.0005).

**Sonuç:** D1 ve D2 sağlandı: doğrulama koşusu hazırlanır (yeni örnekler, önceden gönderilen protokol).

## Uyarılar

Yok.

Pilot keşif amaçlıdır: örnek sayısı küçüktür, karşılaştırmalar düzeltilmemiştir ve hiçbiri doğrulayıcı test değildir. GA-EAX tek çekirdekte koşar; birleştirme kollarında LKH durdurulduktan sonra diğer beş çekirdek boş kalır.
