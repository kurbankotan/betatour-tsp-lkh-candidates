# Run v27 (pilot): birleşim grafında tam çözüm — v27_union14

Tamamlanan örnek: 14 / 14 (okumalar için 12 örnek gerekir; tamam: True).

## Okumalar (10.000 düğüm, 12 örnek; ilk kol daha kısa / eşit / daha uzun | ortalama fark % | %95 aralık | işaret testi p)

- R1 Aynı altı tur: birleşimde tam çözüm / GA-EAX: 6 / 1 / 5 | +0.0050 | [-0.0001, +0.0116] | 1 — tutar mı: False
- R2 Birleşimde tam çözüm / iki GA-EAX süreci (run v26'nın birincil kolu): 1 / 0 / 11 | +0.0111 | [+0.0048, +0.0187] | 0.00635 — tutar mı: False
- R3 Birleşim + BetaTour kenarları / birleşim: 1 / 5 / 6 | +0.0066 | [+0.0012, +0.0119] | 0.125 — tutar mı: False
- R4 Birleşim + BetaTour kenarları / birleşim + en kısa kenarlar: 0 / 5 / 7 | +0.0071 | [+0.0028, +0.0117] | 0.0156 — tutar mı: False

Tam çözüm GA-EAX'ten kısa mı (R1 ya da R2): **False**. Model kenarları katkı veriyor mu (R3 ve R4): **False**.

## Betimsel karşılaştırmalar (bütün örnekler)

- D1 Birleşimde tam çözüm / LKH'nin kendi tur birleştirmesi: 3 / 2 / 9 | +0.0102 | [+0.0025, +0.0185] | 0.146
- D2 Birleşimde tam çözüm / altı LKH süreci: 9 / 0 / 5 | -0.0026 | [-0.0091, +0.0045] | 0.424
- D3 Birleşim + en kısa kenarlar / birleşim: 4 / 8 / 2 | -0.0011 | [-0.0041, +0.0024] | 0.688
- D4 İki GA-EAX süreci / LKH'nin kendi tur birleştirmesi: 13 / 0 / 1 | -0.0046 | [-0.0083, -0.0014] | 0.00183
- D5 Aynı altı tur: GA-EAX / LKH'nin kendi birleştirmesi: 3 / 1 / 10 | +0.0011 | [-0.0019, +0.0039] | 0.0923
- D6 İki GA-EAX süreci / altı LKH süreci: 14 / 0 / 0 | -0.0174 | [-0.0209, -0.0143] | 0.000122

## Tam çözücü

- exact6_50: 5/14 örnekte kanıtlanmış en kısa tur; çözüm süresi ortanca 59.7 s, en çok 119.5 s; çekirdek ortanca 3112 düğüm; kullanılan ek kenar ortalaması 0.00; süre sonrası bulunan sonuç: 0.
- exact6beta_50: 3/14 örnekte kanıtlanmış en kısa tur; çözüm süresi ortanca 59.3 s, en çok 118.8 s; çekirdek ortanca 3250 düğüm; kullanılan ek kenar ortalaması 0.79; süre sonrası bulunan sonuç: 0.
- exact6near_50: 7/14 örnekte kanıtlanmış en kısa tur; çözüm süresi ortanca 45.0 s, en çok 119.3 s; çekirdek ortanca 3166 düğüm; kullanılan ek kenar ortalaması 0.00; süre sonrası bulunan sonuç: 0.
- Tam çözüm (altı tur) ile GA-EAX'in (aynı altı tur) aynı uzunlukta olduğu örnek: 1.
- GA-EAX turlarının altı turun birleşiminde olmayan kenarları (ortalama): altı tur 1.5714285714285714, 102 tur 25.214285714285715.

