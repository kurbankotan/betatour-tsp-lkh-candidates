# Run v29 (doğrulama koşusu): kademeli birleştirme — v29_staged23

Tamamlanan örnek: 23 / 23 (hipotezler için 18 sentetik örnek gerekir; tamam: True).

## Hipotezler (sentetik örnekler; ilk kol daha kısa / eşit / daha uzun | ortalama fark % | %95 aralık | işaret testi p | Holm p)

- H1 Kademeli birleştirme / LKH'nin kendi tur birleştirmesi: 18 / 0 / 0 | -0.0213 | [-0.0261, -0.0166] | 7.63e-06 | 1.53e-05 — destekleniyor mu: True
- H2 Kademeli birleştirme / iki GA-EAX süreci (run v26'nın birincil kolu): 17 / 0 / 1 | -0.0158 | [-0.0203, -0.0113] | 0.000145 | 0.000145 — destekleniyor mu: True

Kademeli birleştirme doğrulandı mı (H1 ve H2): **True**.

## Betimsel karşılaştırmalar (sınıflara göre)

### size:20k
- H1 Kademeli birleştirme / LKH'nin kendi tur birleştirmesi: 12 / 0 / 0 | -0.0183 | [-0.0244, -0.0127] | 0.000488
- H2 Kademeli birleştirme / iki GA-EAX süreci (run v26'nın birincil kolu): 11 / 0 / 1 | -0.0102 | [-0.0136, -0.0067] | 0.00635
- D1 Kademeli birleştirme / altı LKH süreci: 12 / 0 / 0 | -0.0324 | [-0.0399, -0.0255] | 0.000488
- D2 Kademeli birleştirme / 102 turda tek GA-EAX süreci: 11 / 0 / 1 | -0.0102 | [-0.0137, -0.0067] | 0.00635
- D3 İki GA-EAX süreci / LKH'nin kendi tur birleştirmesi: 10 / 0 / 2 | -0.0081 | [-0.0145, -0.0023] | 0.0386
- D4 GA-EAX: 102 tur / altı en iyi tur: 12 / 0 / 0 | -0.0084 | [-0.0130, -0.0049] | 0.000488
- D5 İki GA-EAX süreci / altı LKH süreci: 12 / 0 / 0 | -0.0222 | [-0.0285, -0.0171] | 0.000488
- D6 LKH'nin kendi tur birleştirmesi / altı LKH süreci: 12 / 0 / 0 | -0.0141 | [-0.0188, -0.0097] | 0.000488

### size:50k
- H1 Kademeli birleştirme / LKH'nin kendi tur birleştirmesi: 6 / 0 / 0 | -0.0274 | [-0.0327, -0.0220] | 0.0312
- H2 Kademeli birleştirme / iki GA-EAX süreci (run v26'nın birincil kolu): 6 / 0 / 0 | -0.0270 | [-0.0305, -0.0234] | 0.0312
- D1 Kademeli birleştirme / altı LKH süreci: 6 / 0 / 0 | -0.0856 | [-0.0938, -0.0772] | 0.0312
- D2 Kademeli birleştirme / 102 turda tek GA-EAX süreci: 6 / 0 / 0 | -0.0689 | [-0.0733, -0.0640] | 0.0312
- D3 İki GA-EAX süreci / LKH'nin kendi tur birleştirmesi: 3 / 0 / 3 | -0.0004 | [-0.0051, +0.0042] | 1
- D4 GA-EAX: 102 tur / altı en iyi tur: 0 / 0 / 6 | +0.0420 | [+0.0388, +0.0458] | 0.0312
- D5 İki GA-EAX süreci / altı LKH süreci: 6 / 0 / 0 | -0.0587 | [-0.0636, -0.0529] | 0.0312
- D6 LKH'nin kendi tur birleştirmesi / altı LKH süreci: 6 / 0 / 0 | -0.0583 | [-0.0665, -0.0509] | 0.0312

### class:uni20k
- H1 Kademeli birleştirme / LKH'nin kendi tur birleştirmesi: 6 / 0 / 0 | -0.0265 | [-0.0331, -0.0204] | 0.0312
- H2 Kademeli birleştirme / iki GA-EAX süreci (run v26'nın birincil kolu): 5 / 0 / 1 | -0.0112 | [-0.0164, -0.0055] | 0.219
- D1 Kademeli birleştirme / altı LKH süreci: 6 / 0 / 0 | -0.0388 | [-0.0485, -0.0309] | 0.0312
- D2 Kademeli birleştirme / 102 turda tek GA-EAX süreci: 5 / 0 / 1 | -0.0112 | [-0.0162, -0.0055] | 0.219
- D3 İki GA-EAX süreci / LKH'nin kendi tur birleştirmesi: 5 / 0 / 1 | -0.0153 | [-0.0237, -0.0058] | 0.219
- D4 GA-EAX: 102 tur / altı en iyi tur: 6 / 0 / 0 | -0.0126 | [-0.0200, -0.0071] | 0.0312
- D5 İki GA-EAX süreci / altı LKH süreci: 6 / 0 / 0 | -0.0277 | [-0.0366, -0.0208] | 0.0312
- D6 LKH'nin kendi tur birleştirmesi / altı LKH süreci: 6 / 0 / 0 | -0.0124 | [-0.0199, -0.0060] | 0.0312

### class:clu20k
- H1 Kademeli birleştirme / LKH'nin kendi tur birleştirmesi: 6 / 0 / 0 | -0.0101 | [-0.0139, -0.0062] | 0.0312
- H2 Kademeli birleştirme / iki GA-EAX süreci (run v26'nın birincil kolu): 6 / 0 / 0 | -0.0093 | [-0.0132, -0.0050] | 0.0312
- D1 Kademeli birleştirme / altı LKH süreci: 6 / 0 / 0 | -0.0260 | [-0.0347, -0.0179] | 0.0312
- D2 Kademeli birleştirme / 102 turda tek GA-EAX süreci: 6 / 0 / 0 | -0.0093 | [-0.0133, -0.0049] | 0.0312
- D3 İki GA-EAX süreci / LKH'nin kendi tur birleştirmesi: 5 / 0 / 1 | -0.0009 | [-0.0025, +0.0010] | 0.219
- D4 GA-EAX: 102 tur / altı en iyi tur: 6 / 0 / 0 | -0.0041 | [-0.0052, -0.0030] | 0.0312
- D5 İki GA-EAX süreci / altı LKH süreci: 6 / 0 / 0 | -0.0168 | [-0.0224, -0.0122] | 0.0312
- D6 LKH'nin kendi tur birleştirmesi / altı LKH süreci: 6 / 0 / 0 | -0.0159 | [-0.0213, -0.0116] | 0.0312

### class:uni50k
- H1 Kademeli birleştirme / LKH'nin kendi tur birleştirmesi: 3 / 0 / 0 | -0.0319 | [-0.0357, -0.0252] | 0.25
- H2 Kademeli birleştirme / iki GA-EAX süreci (run v26'nın birincil kolu): 3 / 0 / 0 | -0.0270 | [-0.0340, -0.0222] | 0.25
- D1 Kademeli birleştirme / altı LKH süreci: 3 / 0 / 0 | -0.0864 | [-0.0983, -0.0803] | 0.25
- D2 Kademeli birleştirme / 102 turda tek GA-EAX süreci: 3 / 0 / 0 | -0.0697 | [-0.0747, -0.0632] | 0.25
- D3 İki GA-EAX süreci / LKH'nin kendi tur birleştirmesi: 3 / 0 / 0 | -0.0049 | [-0.0099, -0.0017] | 0.25
- D4 GA-EAX: 102 tur / altı en iyi tur: 0 / 0 / 3 | +0.0427 | [+0.0371, +0.0500] | 0.25
- D5 İki GA-EAX süreci / altı LKH süreci: 3 / 0 / 0 | -0.0594 | [-0.0644, -0.0555] | 0.25
- D6 LKH'nin kendi tur birleştirmesi / altı LKH süreci: 3 / 0 / 0 | -0.0545 | [-0.0627, -0.0455] | 0.25

### class:clu50k
- H1 Kademeli birleştirme / LKH'nin kendi tur birleştirmesi: 3 / 0 / 0 | -0.0229 | [-0.0304, -0.0188] | 0.25
- H2 Kademeli birleştirme / iki GA-EAX süreci (run v26'nın birincil kolu): 3 / 0 / 0 | -0.0269 | [-0.0308, -0.0215] | 0.25
- D1 Kademeli birleştirme / altı LKH süreci: 3 / 0 / 0 | -0.0849 | [-0.0955, -0.0679] | 0.25
- D2 Kademeli birleştirme / 102 turda tek GA-EAX süreci: 3 / 0 / 0 | -0.0682 | [-0.0736, -0.0588] | 0.25
- D3 İki GA-EAX süreci / LKH'nin kendi tur birleştirmesi: 0 / 0 / 3 | +0.0040 | [+0.0004, +0.0090] | 0.25
- D4 GA-EAX: 102 tur / altı en iyi tur: 0 / 0 / 3 | +0.0414 | [+0.0373, +0.0440] | 0.25
- D5 İki GA-EAX süreci / altı LKH süreci: 3 / 0 / 0 | -0.0580 | [-0.0671, -0.0464] | 0.25
- D6 LKH'nin kendi tur birleştirmesi / altı LKH süreci: 3 / 0 / 0 | -0.0620 | [-0.0761, -0.0491] | 0.25

### class:tsplib
- H1 Kademeli birleştirme / LKH'nin kendi tur birleştirmesi: 4 / 1 / 0 | -0.0061 | [-0.0096, -0.0026] | 0.125
- H2 Kademeli birleştirme / iki GA-EAX süreci (run v26'nın birincil kolu): 0 / 1 / 4 | +0.0015 | [+0.0003, +0.0031] | 0.125
- D1 Kademeli birleştirme / altı LKH süreci: 5 / 0 / 0 | -0.0150 | [-0.0176, -0.0117] | 0.0625
- D2 Kademeli birleştirme / 102 turda tek GA-EAX süreci: 0 / 1 / 4 | +0.0015 | [+0.0003, +0.0032] | 0.125
- D3 İki GA-EAX süreci / LKH'nin kendi tur birleştirmesi: 4 / 1 / 0 | -0.0076 | [-0.0117, -0.0031] | 0.125
- D4 GA-EAX: 102 tur / altı en iyi tur: 4 / 1 / 0 | -0.0054 | [-0.0088, -0.0020] | 0.125
- D5 İki GA-EAX süreci / altı LKH süreci: 5 / 0 / 0 | -0.0164 | [-0.0186, -0.0129] | 0.0625
- D6 LKH'nin kendi tur birleştirmesi / altı LKH süreci: 4 / 0 / 1 | -0.0088 | [-0.0144, -0.0033] | 0.375

### all
- H1 Kademeli birleştirme / LKH'nin kendi tur birleştirmesi: 22 / 1 / 0 | -0.0180 | [-0.0227, -0.0136] | 4.77e-07
- H2 Kademeli birleştirme / iki GA-EAX süreci (run v26'nın birincil kolu): 17 / 1 / 5 | -0.0120 | [-0.0166, -0.0075] | 0.0169
- D1 Kademeli birleştirme / altı LKH süreci: 23 / 0 / 0 | -0.0425 | [-0.0546, -0.0316] | 2.38e-07
- D2 Kademeli birleştirme / 102 turda tek GA-EAX süreci: 17 / 1 / 5 | -0.0230 | [-0.0350, -0.0119] | 0.0169
- D3 İki GA-EAX süreci / LKH'nin kendi tur birleştirmesi: 17 / 1 / 5 | -0.0060 | [-0.0100, -0.0023] | 0.0169
- D4 GA-EAX: 102 tur / altı en iyi tur: 16 / 1 / 6 | +0.0054 | [-0.0034, +0.0151] | 0.0525
- D5 İki GA-EAX süreci / altı LKH süreci: 23 / 0 / 0 | -0.0305 | [-0.0384, -0.0232] | 2.38e-07
- D6 LKH'nin kendi tur birleştirmesi / altı LKH süreci: 22 / 0 / 1 | -0.0245 | [-0.0339, -0.0160] | 5.72e-06

## TSPLIB: optimuma uzaklık (%)

- class:tsplib: lkh6 0.0223, trials_50 0.0058, best6_50 0.0112, dual_50 0.0058, lkhmerge_50 0.0134, staged_50 0.0073

## Kademeli kolun süresi

- synthetic: 18 örnek; kullanılan süre / kalan süre ortanca 0.44; aşama 1 ortanca 42 s, yakınsayan grup 72/108; aşama 2 yakınsadı: 18; sonucun kaynağı {'stage2': 18}; 102 turda tek GA-EAX yakınsadı: 0.
- size:20k: 12 örnek; kullanılan süre / kalan süre ortanca 0.40; aşama 1 ortanca 38 s, yakınsayan grup 72/72; aşama 2 yakınsadı: 12; sonucun kaynağı {'stage2': 12}; 102 turda tek GA-EAX yakınsadı: 0.
- size:50k: 6 örnek; kullanılan süre / kalan süre ortanca 0.87; aşama 1 ortanca 180 s, yakınsayan grup 0/36; aşama 2 yakınsadı: 6; sonucun kaynağı {'stage2': 6}; 102 turda tek GA-EAX yakınsadı: 0.
- class:uni20k: 6 örnek; kullanılan süre / kalan süre ortanca 0.42; aşama 1 ortanca 40 s, yakınsayan grup 36/36; aşama 2 yakınsadı: 6; sonucun kaynağı {'stage2': 6}; 102 turda tek GA-EAX yakınsadı: 0.
- class:clu20k: 6 örnek; kullanılan süre / kalan süre ortanca 0.39; aşama 1 ortanca 36 s, yakınsayan grup 36/36; aşama 2 yakınsadı: 6; sonucun kaynağı {'stage2': 6}; 102 turda tek GA-EAX yakınsadı: 0.
- class:uni50k: 3 örnek; kullanılan süre / kalan süre ortanca 0.83; aşama 1 ortanca 180 s, yakınsayan grup 0/18; aşama 2 yakınsadı: 3; sonucun kaynağı {'stage2': 3}; 102 turda tek GA-EAX yakınsadı: 0.
- class:clu50k: 3 örnek; kullanılan süre / kalan süre ortanca 0.90; aşama 1 ortanca 180 s, yakınsayan grup 0/18; aşama 2 yakınsadı: 3; sonucun kaynağı {'stage2': 3}; 102 turda tek GA-EAX yakınsadı: 0.
- class:tsplib: 5 örnek; kullanılan süre / kalan süre ortanca 0.17; aşama 1 ortanca 19 s, yakınsayan grup 30/30; aşama 2 yakınsadı: 5; sonucun kaynağı {'stage2': 5}; 102 turda tek GA-EAX yakınsadı: 5.
- all: 23 örnek; kullanılan süre / kalan süre ortanca 0.40; aşama 1 ortanca 38 s, yakınsayan grup 102/138; aşama 2 yakınsadı: 23; sonucun kaynağı {'stage2': 23}; 102 turda tek GA-EAX yakınsadı: 5.
