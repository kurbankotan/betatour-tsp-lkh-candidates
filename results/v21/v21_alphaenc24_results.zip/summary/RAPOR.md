# BetaTour run v21: aday dosyası kodlaması denetimi (alfa ve baba alanları)

24/24 örnek tamamlandı.

Yüzde fark = 100 x (ilk kol - ikinci kol) / ikinci kol; negatif değer ilk kolun daha kısa tur bulduğunu gösterir.
win/tie/loss: ilk kolun daha kısa, eşit, daha uzun olduğu örnek sayısı. Güven aralığı örnek düzeyinde 5000
bootstrap tekrarından, p değeri kesin iki yönlü işaret testinden gelir.
best6: altı tohumun en iyisi. mean6: aynı tohumlu eşli yüzde farkların altı tohum ortalaması.
Birincil karşılaştırmalar (PROTOCOL_v21.md, koşudan önce yazıldı): P1 (mean6) ve P2 (best6), bütçe sonunda,
ikisi birlikte Holm düzeltmeli. Diğer bütün satırlar ikincildir ve keşif amaçlıdır.

## Birincil karşılaştırmalar

**P1 (mean6): Dosyanın etkisi, POPMUSIC listesi: run v5 dosyası / LKH eşdeğeri.** Run v1-v8'in dosyası sonucu kötüleştirdi. 5/0/19 (ilk kol kısa/eşit/uzun), ortalama fark %+0.0065 (%95 GA +0.0027 ile +0.0103), işaret testi p = 0.0066, Holm p = 0.0132

**P2 (best6): BetaTour (ağaç kodlaması) / kesintisiz POPMUSIC.** Ağaç kodlamalı BetaTour, kesintisiz POPMUSIC'ten daha kısa tur buldu. 18/0/6 (ilk kol kısa/eşit/uzun), ortalama fark %-0.0059 (%95 GA -0.0093 ile -0.0028), işaret testi p = 0.0227, Holm p = 0.0227

## Bütçe sonunda bütün karşılaştırmalar (24 örnek birlikte)

```
key                                                          comparison endpoint  instances  win  tie  loss  mean_delta_pct  median_delta_pct  ci95_low_pct  ci95_high_pct  sign_p
 P1    Dosyanın etkisi, POPMUSIC listesi: run v5 dosyası / LKH eşdeğeri    best6         24    6    0    18         0.00957           0.00848       0.00521        0.01382 0.02266
 P1    Dosyanın etkisi, POPMUSIC listesi: run v5 dosyası / LKH eşdeğeri    mean6         24    5    0    19         0.00653           0.00623       0.00273        0.01033 0.00661
 P2                     BetaTour (ağaç kodlaması) / kesintisiz POPMUSIC    best6         24   18    0     6        -0.00588          -0.00525      -0.00932       -0.00277 0.02266
 P2                     BetaTour (ağaç kodlaması) / kesintisiz POPMUSIC    mean6         24   22    0     2        -0.00279          -0.00701      -0.01080        0.01033 0.00004
 S1        Yeniden başlatmanın kendisi: LKH eşdeğeri dosya / kesintisiz    best6         24   12    0    12        -0.00187          -0.00062      -0.00587        0.00196 1.00000
 S1        Yeniden başlatmanın kendisi: LKH eşdeğeri dosya / kesintisiz    mean6         24   11    0    13         0.00069           0.00115      -0.00305        0.00436 0.83882
 S2 Run v5'teki karşılaştırma: yeniden başlatılan POPMUSIC / kesintisiz    best6         24    3    0    21         0.00770           0.00801       0.00478        0.01046 0.00028
 S2 Run v5'teki karşılaştırma: yeniden başlatılan POPMUSIC / kesintisiz    mean6         24    5    0    19         0.00720           0.00720       0.00384        0.01033 0.00661
 S3          Listenin etkisi, düzeltilmiş dosyalar: BetaTour / POPMUSIC    best6         24   17    0     7        -0.00401          -0.00437      -0.00715       -0.00079 0.06391
 S3          Listenin etkisi, düzeltilmiş dosyalar: BetaTour / POPMUSIC    mean6         24   21    0     3        -0.00348          -0.00891      -0.01167        0.01013 0.00028
 S4              Listenin etkisi, run v5 dosyaları: BetaTour / POPMUSIC    best6         24   21    0     3        -0.00887          -0.00917      -0.01146       -0.00608 0.00028
 S4              Listenin etkisi, run v5 dosyaları: BetaTour / POPMUSIC    mean6         24   22    0     2        -0.01090          -0.00838      -0.01545       -0.00707 0.00004
 S5  Dosyanın etkisi, BetaTour listesi: run v5 dosyası / ağaç kodlaması    best6         24    5    0    19         0.00471           0.00295       0.00199        0.00788 0.00661
 S5  Dosyanın etkisi, BetaTour listesi: run v5 dosyası / ağaç kodlaması    mean6         24    7    0    17        -0.00089           0.00452      -0.01728        0.00883 0.06391
 S6                                      Model / sayım (ağaç kodlaması)    best6         24   12    0    12         0.00035          -0.00022      -0.00288        0.00378 1.00000
 S6                                      Model / sayım (ağaç kodlaması)    mean6         24   14    0    10         0.00620          -0.00174      -0.00377        0.02381 0.54126
 S7                        Sayım (ağaç kodlaması) / kesintisiz POPMUSIC    best6         24   17    0     7        -0.00624          -0.00589      -0.00974       -0.00274 0.06391
 S7                        Sayım (ağaç kodlaması) / kesintisiz POPMUSIC    mean6         24   20    0     4        -0.00899          -0.00599      -0.01515       -0.00421 0.00154
 S8                    Run v5'teki karşılaştırma: BetaTour / kesintisiz    best6         24   12    0    12        -0.00117          -0.00001      -0.00426        0.00196 1.00000
 S8                    Run v5'teki karşılaştırma: BetaTour / kesintisiz    mean6         24   15    0     9        -0.00370          -0.00339      -0.00804        0.00005 0.30746
```

## Ailelere göre birincil uç noktalar

```
 group key                                                       comparison endpoint  instances  win  tie  loss  mean_delta_pct  median_delta_pct  ci95_low_pct  ci95_high_pct  sign_p
clu10k  P1 Dosyanın etkisi, POPMUSIC listesi: run v5 dosyası / LKH eşdeğeri    mean6         12    4    0     8         0.00674           0.00637       0.00117        0.01266 0.38770
clu10k  P2                  BetaTour (ağaç kodlaması) / kesintisiz POPMUSIC    best6         12    8    0     4        -0.00567          -0.00383      -0.01140       -0.00102 0.38770
uni10k  P1 Dosyanın etkisi, POPMUSIC listesi: run v5 dosyası / LKH eşdeğeri    mean6         12    1    0    11         0.00632           0.00575       0.00153        0.01108 0.00635
uni10k  P2                  BetaTour (ağaç kodlaması) / kesintisiz POPMUSIC    best6         12   10    0     2        -0.00610          -0.00657      -0.01053       -0.00173 0.03857
```

## Zaman içinde (bütçenin %25, %50, %75 ve %100'ünde; mean6)

```
key  time_pct  win  tie  loss  mean_delta_pct  ci95_low_pct  ci95_high_pct  sign_p
 P1        25    4    0    20         0.01837       0.01077        0.02609 0.00154
 P1        50    3    0    21         0.01176       0.00740        0.01638 0.00028
 P1        75    4    0    20         0.00836       0.00454        0.01228 0.00154
 P1       100    5    0    19         0.00653       0.00273        0.01033 0.00661
 S1        25    4    0    20         0.01247      -0.00203        0.02619 0.00154
 S1        50    9    0    15        -0.00316      -0.02030        0.00825 0.30746
 S1        75   10    0    14        -0.00101      -0.00862        0.00505 0.54126
 S1       100   11    0    13         0.00069      -0.00305        0.00436 0.83882
 S3        25   17    0     7        -0.00506      -0.02037        0.01207 0.06391
 S3        50   20    0     4        -0.00388      -0.01478        0.01399 0.00154
 S3        75   21    0     3        -0.00334      -0.01370        0.01360 0.00028
 S3       100   21    0     3        -0.00348      -0.01167        0.01013 0.00028
 S5        25    4    0    20         0.00364      -0.01226        0.01593 0.00154
 S5        50    4    0    20         0.00201      -0.01385        0.01194 0.00154
 S5        75    3    0    21         0.00020      -0.01758        0.01090 0.00028
 S5       100    7    0    17        -0.00089      -0.01728        0.00883 0.06391
```

## Kollar: tamamlanan deneme sayısı ve yeniden başlatmada korunabilen kenar payı

kept_share: ilk denemenin turundaki kenarlardan, aday dosyasında alfası 0 olanların payı (LKH'nin yeniden
başlatma kuralının koruyabildiği kenarlar). mean_trials_at_budget: bütçe içinde tamamlanan deneme sayısı
(tohum ortalaması); yeniden başlatılan kollarda ortak ilk deneme ve dosyadan okunan turu yeniden
iyileştiren deneme dahildir.

```
 group        arm  instances  mean_trials_at_budget  trials_vs_pop_full_pct  kept_share  zero_alpha_per_node  prelude_s  list_overhead_s
   all   pop_full         24               315.7292                  0.0000         NaN                  NaN     0.0000           0.0000
   all pop_native         24               308.1806                 -2.3909      0.7551               2.0006    12.2437           0.0000
   all   pop_rank         24               205.0556                -35.0533      0.4432               1.0000    12.2437           0.0000
   all  beta_tree         24               258.7847                -18.0359      0.7551               2.0006    12.7196           0.4759
   all  beta_rank         24               199.6597                -36.7623      0.4904               1.0000    12.6673           0.4236
   all  freq_tree         24               267.4653                -15.2865      0.7551               2.0006    12.4824           0.2387
clu10k   pop_full         12               256.6667                  0.0000         NaN                  NaN     0.0000           0.0000
clu10k pop_native         12               247.7500                 -3.4740      0.7551               2.0007    12.6507           0.0000
clu10k   pop_rank         12               167.1111                -34.8918      0.4431               1.0000    12.6507           0.0000
clu10k  beta_tree         12               210.6389                -17.9329      0.7551               2.0007    13.1262           0.4755
clu10k  beta_rank         12               162.8611                -36.5476      0.4898               1.0000    13.0739           0.4232
clu10k  freq_tree         12               219.2917                -14.5617      0.7551               2.0007    12.8890           0.2383
uni10k   pop_full         12               374.7917                  0.0000         NaN                  NaN     0.0000           0.0000
uni10k pop_native         12               368.6111                 -1.6491      0.7551               2.0005    11.8367           0.0000
uni10k   pop_rank         12               243.0000                -35.1640      0.4433               1.0000    11.8367           0.0000
uni10k  beta_tree         12               306.9306                -18.1064      0.7551               2.0005    12.3130           0.4763
uni10k  beta_rank         12               236.4583                -36.9094      0.4910               1.0000    12.2606           0.4239
uni10k  freq_tree         12               315.6389                -15.7828      0.7551               2.0004    12.0758           0.2391
```

Ham tablolar: summary/per_instance.csv, per_seed.csv, paired_stats.csv (bütün zaman noktaları), arms.csv.
Aday dosyaları candidates/, ilk aşama dizileri stages/<örnek>/phase1.npz içindedir.