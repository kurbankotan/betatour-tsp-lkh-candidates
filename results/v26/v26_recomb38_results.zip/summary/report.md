# BetaTour run v26: doğrulama koşusu (LKH-3 turlarının GA-EAX ile birleştirilmesi)

38/38 örnek tamamlandı.

Birincil kol: `dual_50`. Altı LKH süreci bütçenin %50 anında durur; iki GA-EAX süreci aynı anda koşar: biri her sürecin en iyi turu ve son 16 atılan deneme turuyla (`trials_50`), öteki altı en iyi turla (`best6_50`). Sonuç ikisinden kısa olanıdır. Karşılaştırmalar: `lkh6` (aynı altı süreç bütçenin sonuna kadar), `lkhmerge_50` (altı en iyi tur LKH'nin kendi tur birleştirmesine verilir) ve `cascade` (bilinen melez). Bütün zamanlar duvar saatidir.

## Doğrulayıcı testler (koşudan önce yazıldı)

| Test | Karşılaştırma | Örnekler | Kısa/eşit/uzun | Ortalama fark (%) | %95 GA | Ortanca (%) | p | Holm p | Destek |
|---|---|---|---|---|---|---|---|---|---|
| H1 | `dual_50` / `lkh6` | synthetic (28) | 27/0/1 | -0.0240 | -0.0326 ile -0.0161 | -0.0172 | 2.16e-07 | 8.64e-07 | **evet** |
| H2 | `dual_50` / `lkhmerge_50` | synthetic (28) | 18/0/10 | -0.0034 | -0.0060 ile -0.0010 | -0.0023 | 1.85e-01 | 1.85e-01 | **hayır** |
| H3 | `dual_50` / `cascade` | synthetic (28) | 24/0/4 | -0.0315 | -0.0519 ile -0.0144 | -0.0078 | 1.80e-04 | 3.60e-04 | **evet** |
| H4 | `trials_50` / `best6_50` | n10k (16) | 15/1/0 | -0.0067 | -0.0089 ile -0.0045 | -0.0078 | 6.10e-05 | 1.83e-04 | **evet** |

## Bütçe sonunda karşılaştırmalar (doğrulayıcı testler dışında hepsi keşif amaçlıdır)

| Grup | Karşılaştırma | Örnek | Kısa/eşit/uzun | Ortalama fark (%) | %95 GA | Ortanca (%) | p |
|---|---|---|---|---|---|---|---|
| synthetic | H1: `dual_50` / `lkh6` | 28 | 27/0/1 | -0.0240 | -0.0326 ile -0.0161 | -0.0172 | 0.0000 |
| synthetic | H2: `dual_50` / `lkhmerge_50` | 28 | 18/0/10 | -0.0034 | -0.0060 ile -0.0010 | -0.0023 | 0.1849 |
| synthetic | H3: `dual_50` / `cascade` | 28 | 24/0/4 | -0.0315 | -0.0519 ile -0.0144 | -0.0078 | 0.0002 |
| synthetic | H4: `trials_50` / `best6_50` | 28 | 17/1/10 | +0.0060 | -0.0014 ile +0.0144 | -0.0018 | 0.2478 |
| synthetic | S1: `trials_50` / `lkh6` | 28 | 27/0/1 | -0.0138 | -0.0169 ile -0.0103 | -0.0163 | 0.0000 |
| synthetic | S2: `best6_50` / `lkh6` | 28 | 25/0/3 | -0.0198 | -0.0295 ile -0.0106 | -0.0115 | 0.0000 |
| synthetic | S3: `lkhmerge_50` / `lkh6` | 28 | 25/0/3 | -0.0206 | -0.0291 ile -0.0126 | -0.0128 | 0.0000 |
| synthetic | S4: `cascade` / `lkh6` | 28 | 17/0/11 | +0.0075 | -0.0036 ile +0.0201 | -0.0060 | 0.3449 |
| synthetic | S5: `best6_50` / `lkhmerge_50` | 28 | 8/2/18 | +0.0008 | -0.0016 ile +0.0029 | +0.0017 | 0.0755 |
| synthetic | R1: `eax_scratch` / `lkh6` | 16 | 3/0/13 | +0.0422 | +0.0237 ile +0.0622 | +0.0366 | 0.0213 |
| synthetic | R2: `dual_50` / `eax_scratch` | 16 | 15/0/1 | -0.0546 | -0.0768 ile -0.0336 | -0.0574 | 0.0005 |
| n10k | H1: `dual_50` / `lkh6` | 16 | 15/0/1 | -0.0125 | -0.0168 ile -0.0068 | -0.0161 | 0.0005 |
| n10k | H2: `dual_50` / `lkhmerge_50` | 16 | 13/0/3 | -0.0057 | -0.0086 ile -0.0030 | -0.0056 | 0.0213 |
| n10k | H3: `dual_50` / `cascade` | 16 | 14/0/2 | -0.0060 | -0.0094 ile -0.0027 | -0.0051 | 0.0042 |
| n10k | H4: `trials_50` / `best6_50` | 16 | 15/1/0 | -0.0067 | -0.0089 ile -0.0045 | -0.0078 | 0.0001 |
| n10k | S1: `trials_50` / `lkh6` | 16 | 15/0/1 | -0.0125 | -0.0168 ile -0.0067 | -0.0161 | 0.0005 |
| n10k | S2: `best6_50` / `lkh6` | 16 | 13/0/3 | -0.0058 | -0.0108 ile +0.0009 | -0.0079 | 0.0213 |
| n10k | S3: `lkhmerge_50` / `lkh6` | 16 | 13/0/3 | -0.0068 | -0.0113 ile -0.0009 | -0.0098 | 0.0213 |
| n10k | S4: `cascade` / `lkh6` | 16 | 13/0/3 | -0.0065 | -0.0125 ile +0.0007 | -0.0114 | 0.0213 |
| n10k | S5: `best6_50` / `lkhmerge_50` | 16 | 4/2/10 | +0.0010 | -0.0015 ile +0.0033 | +0.0005 | 0.1796 |
| n10k | R1: `eax_scratch` / `lkh6` | 16 | 3/0/13 | +0.0422 | +0.0237 ile +0.0622 | +0.0366 | 0.0213 |
| n10k | R2: `dual_50` / `eax_scratch` | 16 | 15/0/1 | -0.0546 | -0.0768 ile -0.0336 | -0.0574 | 0.0005 |
| n20k | H1: `dual_50` / `lkh6` | 6 | 6/0/0 | -0.0152 | -0.0194 ile -0.0112 | -0.0142 | 0.0312 |
| n20k | H2: `dual_50` / `lkhmerge_50` | 6 | 1/0/5 | +0.0023 | -0.0007 ile +0.0055 | +0.0018 | 0.2188 |
| n20k | H3: `dual_50` / `cascade` | 6 | 4/0/2 | -0.0057 | -0.0185 ile +0.0073 | -0.0065 | 0.6875 |
| n20k | H4: `trials_50` / `best6_50` | 6 | 2/0/4 | +0.0012 | -0.0033 ile +0.0055 | +0.0027 | 0.6875 |
| n20k | S1: `trials_50` / `lkh6` | 6 | 6/0/0 | -0.0120 | -0.0164 ile -0.0082 | -0.0105 | 0.0312 |
| n20k | S2: `best6_50` / `lkh6` | 6 | 6/0/0 | -0.0132 | -0.0173 ile -0.0102 | -0.0117 | 0.0312 |
| n20k | S3: `lkhmerge_50` / `lkh6` | 6 | 6/0/0 | -0.0175 | -0.0226 ile -0.0130 | -0.0170 | 0.0312 |
| n20k | S4: `cascade` / `lkh6` | 6 | 4/0/2 | -0.0095 | -0.0230 ile +0.0021 | -0.0089 | 0.6875 |
| n20k | S5: `best6_50` / `lkhmerge_50` | 6 | 0/0/6 | +0.0043 | +0.0022 ile +0.0068 | +0.0032 | 0.0312 |
| n50k | H1: `dual_50` / `lkh6` | 6 | 6/0/0 | -0.0637 | -0.0716 ile -0.0550 | -0.0655 | 0.0312 |
| n50k | H2: `dual_50` / `lkhmerge_50` | 6 | 4/0/2 | -0.0032 | -0.0108 ile +0.0030 | -0.0022 | 0.6875 |
| n50k | H3: `dual_50` / `cascade` | 6 | 6/0/0 | -0.1256 | -0.1352 ile -0.1139 | -0.1319 | 0.0312 |
| n50k | H4: `trials_50` / `best6_50` | 6 | 0/0/6 | +0.0447 | +0.0378 ile +0.0512 | +0.0467 | 0.0312 |
| n50k | S1: `trials_50` / `lkh6` | 6 | 6/0/0 | -0.0191 | -0.0246 ile -0.0143 | -0.0172 | 0.0312 |
| n50k | S2: `best6_50` / `lkh6` | 6 | 6/0/0 | -0.0637 | -0.0714 ile -0.0555 | -0.0655 | 0.0312 |
| n50k | S3: `lkhmerge_50` / `lkh6` | 6 | 6/0/0 | -0.0605 | -0.0679 ile -0.0533 | -0.0590 | 0.0312 |
| n50k | S4: `cascade` / `lkh6` | 6 | 0/0/6 | +0.0619 | +0.0498 ile +0.0760 | +0.0596 | 0.0312 |
| n50k | S5: `best6_50` / `lkhmerge_50` | 6 | 4/0/2 | -0.0032 | -0.0103 ile +0.0030 | -0.0022 | 0.6875 |
| tsplib_new | H1: `dual_50` / `lkh6` | 5 | 0/4/1 | +0.0012 | +0.0000 ile +0.0037 | +0.0000 | 1.0000 |
| tsplib_new | H2: `dual_50` / `lkhmerge_50` | 5 | 0/5/0 | +0.0000 | +0.0000 ile +0.0000 | +0.0000 | 1.0000 |
| tsplib_new | H3: `dual_50` / `cascade` | 5 | 1/4/0 | -0.0023 | -0.0070 ile +0.0000 | +0.0000 | 1.0000 |
| tsplib_new | H4: `trials_50` / `best6_50` | 5 | 0/5/0 | +0.0000 | +0.0000 ile +0.0000 | +0.0000 | 1.0000 |
| tsplib_new | S1: `trials_50` / `lkh6` | 5 | 0/4/1 | +0.0012 | +0.0000 ile +0.0037 | +0.0000 | 1.0000 |
| tsplib_new | S2: `best6_50` / `lkh6` | 5 | 0/4/1 | +0.0012 | +0.0000 ile +0.0037 | +0.0000 | 1.0000 |
| tsplib_new | S3: `lkhmerge_50` / `lkh6` | 5 | 0/4/1 | +0.0012 | +0.0000 ile +0.0037 | +0.0000 | 1.0000 |
| tsplib_new | S4: `cascade` / `lkh6` | 5 | 0/3/2 | +0.0036 | +0.0000 ile +0.0083 | +0.0000 | 0.5000 |
| tsplib_new | S5: `best6_50` / `lkhmerge_50` | 5 | 0/5/0 | +0.0000 | +0.0000 ile +0.0000 | +0.0000 | 1.0000 |
| tsplib_new | R1: `eax_scratch` / `lkh6` | 5 | 1/3/1 | +0.0329 | -0.0014 ile +0.1001 | +0.0000 | 1.0000 |
| tsplib_new | R2: `dual_50` / `eax_scratch` | 5 | 1/3/1 | -0.0316 | -0.0999 ile +0.0051 | +0.0000 | 1.0000 |
| tsplib_pilot | H1: `dual_50` / `lkh6` | 5 | 5/0/0 | -0.0175 | -0.0207 ile -0.0133 | -0.0189 | 0.0625 |
| tsplib_pilot | H2: `dual_50` / `lkhmerge_50` | 5 | 5/0/0 | -0.0115 | -0.0178 ile -0.0055 | -0.0121 | 0.0625 |
| tsplib_pilot | H3: `dual_50` / `cascade` | 5 | 2/0/3 | -0.0008 | -0.0097 ile +0.0085 | +0.0014 | 1.0000 |
| tsplib_pilot | H4: `trials_50` / `best6_50` | 5 | 4/1/0 | -0.0061 | -0.0108 ile -0.0014 | -0.0047 | 0.1250 |
| tsplib_pilot | S1: `trials_50` / `lkh6` | 5 | 5/0/0 | -0.0175 | -0.0207 ile -0.0132 | -0.0189 | 0.0625 |
| tsplib_pilot | S2: `best6_50` / `lkh6` | 5 | 4/0/1 | -0.0114 | -0.0185 ile -0.0029 | -0.0147 | 0.3750 |
| tsplib_pilot | S3: `lkhmerge_50` / `lkh6` | 5 | 4/0/1 | -0.0060 | -0.0113 ile -0.0014 | -0.0059 | 0.3750 |
| tsplib_pilot | S4: `cascade` / `lkh6` | 5 | 4/0/1 | -0.0167 | -0.0291 ile -0.0051 | -0.0190 | 0.3750 |
| tsplib_pilot | S5: `best6_50` / `lkhmerge_50` | 5 | 4/0/1 | -0.0054 | -0.0141 ile +0.0014 | -0.0012 | 0.3750 |

## Optimuma uzaklık (%): tsplib_new

| Örnek | Düğüm | Bütçe (s) | `lkh6` | `best6_50` | `trials_50` | `dual_50` | `lkhmerge_50` | `cascade` | `eax_scratch` |
|---|---|---|---|---|---|---|---|---|---|
| pcb3038 | 3038 | 61 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| fl3795 | 3795 | 76 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.1668 |
| fnl4461 | 4461 | 89 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 |
| rl5915 | 5915 | 118 | 0.0023 | 0.0085 | 0.0085 | 0.0085 | 0.0085 | 0.0085 | 0.0000 |
| rl5934 | 5934 | 119 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0000 | 0.0117 | 0.0000 |
| ortalama | | | 0.0005 | 0.0017 | 0.0017 | 0.0017 | 0.0017 | 0.0040 | 0.0334 |

## Optimuma uzaklık (%): tsplib_pilot

| Örnek | Düğüm | Bütçe (s) | `lkh6` | `best6_50` | `trials_50` | `dual_50` | `lkhmerge_50` | `cascade` | `eax_scratch` |
|---|---|---|---|---|---|---|---|---|---|
| rl11849 | 11849 | 237 | 0.0391 | 0.0168 | 0.0168 | 0.0168 | 0.0392 | 0.0000 | - |
| usa13509 | 13509 | 270 | 0.0213 | 0.0047 | 0.0037 | 0.0037 | 0.0048 | 0.0023 | - |
| brd14051 | 14051 | 281 | 0.0236 | 0.0089 | 0.0043 | 0.0043 | 0.0164 | 0.0013 | - |
| d15112 | 15112 | 302 | 0.0135 | 0.0170 | 0.0041 | 0.0041 | 0.0129 | 0.0149 | - |
| d18512 | 18512 | 370 | 0.0206 | 0.0135 | 0.0017 | 0.0017 | 0.0147 | 0.0160 | - |
| ortalama | | | 0.0236 | 0.0122 | 0.0061 | 0.0061 | 0.0176 | 0.0069 | - |

## Mekanizma (sınıf ortalamaları)

| Sınıf | Örnek | Kesimde deneme/süreç | 102 turun birleşim kenarı/düğüm | GA-EAX yakınsadı (102 tur / 6 tur) | Birincil kolun kaynağı | LKH son uzunluğuna ulaşma (bütçenin kesri) | LKH birleştirmesi: turu olan süreç, kesimdeki tura göre kazanç (%) | Süreç-saniye payı (birincil / LKH birleştirmesi) |
|---|---|---|---|---|---|---|---|---|
| n10k | 16 | 127 | 1.462 | 14/16 / 16/16 | best6_50+trials_50 1, trials_50 15 | 0.53 (15/16 örnek) | 6.0, -0.0189 | 0.57 / 1.00 |
| n20k | 6 | 72 | 1.524 | 0/6 / 6/6 | best6_50 4, trials_50 2 | 0.53 (6/6 örnek) | 6.0, -0.0448 | 0.59 / 1.00 |
| n50k | 6 | 57 | 1.576 | 0/6 / 6/6 | best6_50 6 | 0.52 (6/6 örnek) | 6.0, -0.0782 | 0.61 / 1.00 |
| tsplib | 10 | 447 | 1.378 | 10/10 / 10/10 | best6_50+trials_50 6, trials_50 4 | 0.40 (9/10 örnek) | 6.0, -0.0077 | 0.53 / 1.00 |

## Uyarılar

Yok.

Doğrulayıcı testler yalnızca dört testtir (H1-H4) ve yalnızca yeni sentetik örnekleri kullanır; öteki bütün karşılaştırmalar keşif amaçlıdır ve düzeltilmemiştir. GA-EAX tek çekirdekte koşar: birincil kol kesimden sonra iki çekirdek kullanır, `lkh6` ve LKH'nin kendi birleştirmesi altı çekirdek kullanır.
