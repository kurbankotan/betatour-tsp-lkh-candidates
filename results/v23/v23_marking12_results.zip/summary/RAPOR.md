# BetaTour run v23: yeniden başlatma işaretlemesi (keşif koşusu)

12/12 örnek tamamlandı.

Bu koşu keşif amaçlıdır: p değerleri düzeltmesizdir ve hiçbir satır doğrulayıcı bir test değildir. Daha iyi
görünen bir işaretleme, makalede yer almadan önce kendi protokolü olan ayrı bir koşuda sınanır.

Yüzde fark = 100 x (ilk kol - ikinci kol) / ikinci kol; negatif değer ilk kolun daha kısa tur bulduğunu gösterir.
win/tie/loss: ilk kolun daha kısa, eşit, daha uzun olduğu örnek sayısı. Güven aralığı örnek düzeyinde 5000
bootstrap tekrarından, p değeri kesin iki yönlü işaret testinden gelir.
best6: altı tohumun en iyisi. mean6: aynı tohumlu eşli yüzde farkların altı tohum ortalaması.
Ana okumalar (PROTOCOL_v23.md, koşudan önce yazıldı): M1, M2 ve M3; mean6, bütçe sonunda. Karar kuralı:
işaret testi p < 0,05 ve yeni işaretleme daha çok örnekte kısaysa o işaretleme için doğrulama koşusu hazırlanır.

## Ana okumalar

**M1 (mean6): Model işaretlemesi / ağaç işaretlemesi (BetaTour listesi).** Karar kuralı sağlanmadı: doğrulama koşusu hazırlanmaz (bu, fark olmadığının kanıtı değildir; güven aralığına bakın). 7/0/5 (ilk kol kısa/eşit/uzun), işaret testi p = 0.7744 (düzeltmesiz, keşif amaçlı), ortalama fark %-0.0012 (%95 GA -0.0039 ile +0.0022), ortanca %-0.0022

**M2 (mean6): Sayım işaretlemesi / ağaç işaretlemesi (BetaTour listesi).** Karar kuralı sağlanmadı: doğrulama koşusu hazırlanmaz (bu, fark olmadığının kanıtı değildir; güven aralığına bakın). 6/0/6 (ilk kol kısa/eşit/uzun), işaret testi p = 1.0000 (düzeltmesiz, keşif amaçlı), ortalama fark %-0.0022 (%95 GA -0.0064 ile +0.0024), ortanca %-0.0027

**M3 (mean6): Model işaretlemesi / ağaç işaretlemesi (POPMUSIC listesi).** Karar kuralı sağlanmadı: doğrulama koşusu hazırlanmaz (bu, fark olmadığının kanıtı değildir; güven aralığına bakın). 6/0/6 (ilk kol kısa/eşit/uzun), işaret testi p = 1.0000 (düzeltmesiz, keşif amaçlı), ortalama fark %-0.0030 (%95 GA -0.0094 ile +0.0028), ortanca %-0.0002

## Bütçe sonunda bütün karşılaştırmalar (12 örnek birlikte)

```
key                                                                         comparison endpoint  instances  win  tie  loss  mean_delta_pct  median_delta_pct  ci95_low_pct  ci95_high_pct  sign_p
 M1                          Model işaretlemesi / ağaç işaretlemesi (BetaTour listesi)    best6         12    6    0     6         0.00143          -0.00007      -0.00322        0.00678 1.00000
 M1                          Model işaretlemesi / ağaç işaretlemesi (BetaTour listesi)    mean6         12    7    0     5        -0.00117          -0.00225      -0.00391        0.00217 0.77441
 M2                          Sayım işaretlemesi / ağaç işaretlemesi (BetaTour listesi)    best6         12    6    0     6         0.00072          -0.00051      -0.00383        0.00594 1.00000
 M2                          Sayım işaretlemesi / ağaç işaretlemesi (BetaTour listesi)    mean6         12    6    0     6        -0.00222          -0.00273      -0.00640        0.00238 1.00000
 M3                          Model işaretlemesi / ağaç işaretlemesi (POPMUSIC listesi)    best6         12    7    0     5        -0.00189          -0.00360      -0.00649        0.00234 0.77441
 M3                          Model işaretlemesi / ağaç işaretlemesi (POPMUSIC listesi)    mean6         12    6    0     6        -0.00299          -0.00019      -0.00944        0.00276 1.00000
 S1                                      Model / sayım işaretlemesi (BetaTour listesi)    best6         12    4    0     8         0.00072           0.00118      -0.00164        0.00297 0.38770
 S1                                      Model / sayım işaretlemesi (BetaTour listesi)    mean6         12    4    0     8         0.00105           0.00311      -0.00191        0.00374 0.38770
 S2                                BetaTour + model işaretlemesi / kesintisiz POPMUSIC    best6         12    8    0     4        -0.00460          -0.00439      -0.00766       -0.00163 0.38770
 S2                                BetaTour + model işaretlemesi / kesintisiz POPMUSIC    mean6         12    9    0     3        -0.00299          -0.00546      -0.00791        0.00380 0.14600
 S3                                BetaTour + sayım işaretlemesi / kesintisiz POPMUSIC    best6         12   10    0     2        -0.00532          -0.00541      -0.00831       -0.00218 0.03857
 S3                                BetaTour + sayım işaretlemesi / kesintisiz POPMUSIC    mean6         12    8    0     4        -0.00404          -0.00788      -0.01022        0.00407 0.38770
 S4 BetaTour, ağaç işaretlemesi / kesintisiz POPMUSIC (run v21'deki P2, yeni örnekler)    best6         12   10    0     2        -0.00603          -0.00682      -0.01028       -0.00224 0.03857
 S4 BetaTour, ağaç işaretlemesi / kesintisiz POPMUSIC (run v21'deki P2, yeni örnekler)    mean6         12    9    0     3        -0.00182          -0.00467      -0.00669        0.00527 0.14600
 S5                                POPMUSIC + model işaretlemesi / kesintisiz POPMUSIC    best6         12    8    0     4        -0.00415          -0.00413      -0.00830        0.00006 0.38770
 S5                                POPMUSIC + model işaretlemesi / kesintisiz POPMUSIC    mean6         12    7    0     5         0.00253          -0.00141      -0.00330        0.01124 0.77441
 S6                       Yeniden başlatmanın kendisi: LKH eşdeğeri dosya / kesintisiz    best6         12    9    0     3        -0.00227          -0.00262      -0.00484        0.00072 0.14600
 S6                       Yeniden başlatmanın kendisi: LKH eşdeğeri dosya / kesintisiz    mean6         12    4    0     8         0.00553           0.00106      -0.00213        0.01489 0.38770
 S7                            Listenin etkisi, ağaç işaretlemesi: BetaTour / POPMUSIC    best6         12   10    0     2        -0.00377          -0.00469      -0.00718       -0.00057 0.03857
 S7                            Listenin etkisi, ağaç işaretlemesi: BetaTour / POPMUSIC    mean6         12    9    0     3        -0.00734          -0.00929      -0.01258       -0.00205 0.14600
 S8                           Listenin etkisi, model işaretlemesi: BetaTour / POPMUSIC    best6         12    5    0     7        -0.00045           0.00101      -0.00561        0.00477 0.77441
 S8                           Listenin etkisi, model işaretlemesi: BetaTour / POPMUSIC    mean6         12    9    0     3        -0.00552          -0.00520      -0.00891       -0.00225 0.14600
```

## Ailelere göre ana okumalar

```
 group key                                                comparison endpoint  instances  win  tie  loss  mean_delta_pct  median_delta_pct  ci95_low_pct  ci95_high_pct  sign_p
clu10k  M1 Model işaretlemesi / ağaç işaretlemesi (BetaTour listesi)    mean6          6    3    0     3        -0.00126          -0.00109      -0.00421        0.00162  1.0000
clu10k  M2 Sayım işaretlemesi / ağaç işaretlemesi (BetaTour listesi)    mean6          6    2    0     4         0.00065           0.00126      -0.00540        0.00658  0.6875
clu10k  M3 Model işaretlemesi / ağaç işaretlemesi (POPMUSIC listesi)    mean6          6    3    0     3        -0.00236          -0.00019      -0.01393        0.00691  1.0000
uni10k  M1 Model işaretlemesi / ağaç işaretlemesi (BetaTour listesi)    mean6          6    4    0     2        -0.00108          -0.00327      -0.00565        0.00464  0.6875
uni10k  M2 Sayım işaretlemesi / ağaç işaretlemesi (BetaTour listesi)    mean6          6    4    0     2        -0.00509          -0.00743      -0.01023        0.00093  0.6875
uni10k  M3 Model işaretlemesi / ağaç işaretlemesi (POPMUSIC listesi)    mean6          6    3    0     3        -0.00362          -0.00207      -0.01054        0.00285  1.0000
```

## Zaman içinde (bütçenin %25, %50, %75 ve %100'ünde; mean6)

```
key  time_pct  win  tie  loss  mean_delta_pct  ci95_low_pct  ci95_high_pct  sign_p
 M1        25    7    0     5        -0.00298      -0.01344        0.00801 0.77441
 M1        50    8    0     4        -0.00160      -0.00725        0.00472 0.38770
 M1        75    8    0     4        -0.00013      -0.00504        0.00599 0.38770
 M1       100    7    0     5        -0.00117      -0.00391        0.00217 0.77441
 M2        25    8    0     4        -0.00793      -0.01647        0.00236 0.38770
 M2        50    8    0     4        -0.00299      -0.00994        0.00566 0.38770
 M2        75    8    0     4        -0.00193      -0.00821        0.00531 0.38770
 M2       100    6    0     6        -0.00222      -0.00640        0.00238 1.00000
 M3        25    7    0     5        -0.00133      -0.01632        0.01549 0.77441
 M3        50    6    0     6         0.00169      -0.00689        0.01091 1.00000
 M3        75    5    0     7        -0.00152      -0.00943        0.00525 0.77441
 M3       100    6    0     6        -0.00299      -0.00944        0.00276 1.00000
```

## Kollar: en kısa tur, deneme sayısı ve yeniden başlatmada korunabilen kenar payı

shortest_best6 / shortest_mean6: kolun, altı kol içinde en kısa turu (altı tohumun en iyisi / ortalaması)
bulduğu örnek sayısı; eşitlikte her kol sayılır. kept_share: ilk denemenin turundaki kenarlardan, aday
dosyasında alfası 0 olanların payı (LKH'nin yeniden başlatma kuralının koruyabildiği kenarlar); 1 - kept_share
her denemede bozulmaya açık bırakılan paydır. mean_trials_at_budget: bütçe içinde tamamlanan deneme sayısı
(tohum ortalaması). list_overhead_s: kolun bütçesinden düşülen hazırlık süresi (model, liste, işaretleme).

```
 group        arm  instances  shortest_best6  shortest_mean6  mean_trials_at_budget  trials_vs_pop_full_pct  kept_share  zero_alpha_per_node  prelude_s  list_overhead_s
   all   pop_full         12               0               2               311.4028                  0.0000         NaN                  NaN     0.0000           0.0000
   all pop_native         12               1               1               312.5000                  0.3523      0.7566               2.0007    12.6679           0.0000
   all  pop_model         12               3               1               414.1528                 32.9959      0.8226               1.7182    13.2218           0.5539
   all  beta_tree         12               3               3               257.3889                -17.3453      0.7566               2.0006    13.1484           0.4805
   all beta_model         12               2               0               364.0833                 16.9172      0.8280               1.7320    13.3286           0.6608
   all beta_count         12               3               5               327.0833                  5.0355      0.8270               1.6947    13.3382           0.6703
clu10k   pop_full          6               0               1               232.8333                  0.0000         NaN                  NaN     0.0000           0.0000
clu10k pop_native          6               0               1               226.3056                 -2.8036      0.7556               2.0012    13.5304           0.0000
clu10k  pop_model          6               2               1               315.0000                 35.2899      0.8143               1.7060    14.0843           0.5538
clu10k  beta_tree          6               2               2               194.8056                -16.3326      0.7556               2.0012    14.0120           0.4815
clu10k beta_model          6               1               0               267.5278                 14.9010      0.8198               1.7201    14.1926           0.6622
clu10k beta_count          6               1               1               235.6389                  1.2050      0.8189               1.6802    14.2038           0.6733
uni10k   pop_full          6               0               1               389.9722                  0.0000         NaN                  NaN     0.0000           0.0000
uni10k pop_native          6               1               0               398.6944                  2.2366      0.7575               2.0002    11.8053           0.0000
uni10k  pop_model          6               1               0               513.3056                 31.6262      0.8309               1.7305    12.3593           0.5540
uni10k  beta_tree          6               1               1               319.9722                -17.9500      0.7575               2.0001    12.2848           0.4794
uni10k beta_model          6               1               0               460.6389                 18.1209      0.8362               1.7439    12.4647           0.6593
uni10k beta_count          6               2               4               418.5278                  7.3225      0.8352               1.7092    12.4726           0.6673
```

Ham tablolar: summary/per_instance.csv, per_seed.csv, paired_stats.csv (bütün zaman noktaları), arms.csv.
Aday dosyaları candidates/, ilk aşama dizileri stages/<örnek>/phase1.npz içindedir.