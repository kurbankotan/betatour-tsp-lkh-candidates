# Run v28 (pilot): kademeli birleştirme — v28_staged14

Tamamlanan örnek: 14 / 14 (okumalar için 12 örnek gerekir; tamam: True).

## Okumalar (20.000 düğüm, 12 örnek; ilk kol daha kısa / eşit / daha uzun | ortalama fark % | %95 aralık | işaret testi p)

- R1 Kademeli birleştirme / iki GA-EAX süreci (run v26'nın birincil kolu): 10 / 0 / 2 | -0.0097 | [-0.0146, -0.0052] | 0.0386 — tutar mı: True
- R2 Kademeli birleştirme / LKH'nin kendi tur birleştirmesi: 12 / 0 / 0 | -0.0131 | [-0.0171, -0.0093] | 0.000488 — tutar mı: True

Kademeli birleştirme hem iki GA-EAX sürecinden hem LKH'nin kendi birleştirmesinden kısa mı (R1 ve R2): **True**.

## Betimsel karşılaştırmalar (bütün örnekler)

- D1 Kademeli birleştirme / altı LKH süreci: 14 / 0 / 0 | -0.0395 | [-0.0534, -0.0279] | 0.000122
- D2 Kademeli birleştirme / 102 turda tek GA-EAX süreci: 12 / 0 / 2 | -0.0203 | [-0.0352, -0.0082] | 0.0129
- D3 İki GA-EAX süreci / LKH'nin kendi tur birleştirmesi: 9 / 0 / 5 | -0.0028 | [-0.0063, +0.0006] | 0.424
- D4 GA-EAX: 102 tur / altı en iyi tur: 11 / 0 / 3 | +0.0024 | [-0.0062, +0.0133] | 0.0574
- D5 İki GA-EAX süreci / altı LKH süreci: 14 / 0 / 0 | -0.0264 | [-0.0356, -0.0187] | 0.000122
- D6 LKH'nin kendi tur birleştirmesi / altı LKH süreci: 13 / 0 / 1 | -0.0236 | [-0.0333, -0.0155] | 0.00183

## Kademeli kolun süresi

- decision: 12 örnek; kullanılan süre / kalan süre ortanca 0.41; aşama 1 ortanca 37 s, yakınsayan grup 72/72; aşama 2 yakınsadı: 12; sonucun kaynağı {'stage2': 12}; 102 turda tek GA-EAX yakınsadı: 0.
- class:uni20k: 6 örnek; kullanılan süre / kalan süre ortanca 0.44; aşama 1 ortanca 40 s, yakınsayan grup 36/36; aşama 2 yakınsadı: 6; sonucun kaynağı {'stage2': 6}; 102 turda tek GA-EAX yakınsadı: 0.
- class:clu20k: 6 örnek; kullanılan süre / kalan süre ortanca 0.40; aşama 1 ortanca 36 s, yakınsayan grup 36/36; aşama 2 yakınsadı: 6; sonucun kaynağı {'stage2': 6}; 102 turda tek GA-EAX yakınsadı: 0.
- class:uni50k: 1 örnek; kullanılan süre / kalan süre ortanca 0.93; aşama 1 ortanca 180 s, yakınsayan grup 0/6; aşama 2 yakınsadı: 1; sonucun kaynağı {'stage2': 1}; 102 turda tek GA-EAX yakınsadı: 0.
- class:clu50k: 1 örnek; kullanılan süre / kalan süre ortanca 0.97; aşama 1 ortanca 180 s, yakınsayan grup 0/6; aşama 2 yakınsadı: 1; sonucun kaynağı {'stage2': 1}; 102 turda tek GA-EAX yakınsadı: 0.
- all: 14 örnek; kullanılan süre / kalan süre ortanca 0.42; aşama 1 ortanca 38 s, yakınsayan grup 72/84; aşama 2 yakınsadı: 14; sonucun kaynağı {'stage2': 14}; 102 turda tek GA-EAX yakınsadı: 0.
