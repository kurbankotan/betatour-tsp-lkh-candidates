# BetaTour residual 4+1 candidate experiment

Complete: 40/40 new 10k/20k synthetic instances. Primary: BetaTour 4+1 vs frequency 4+1.

Each 4+1 list retains four equal-five POPMUSIC entries and appends one undirected POP-novel edge.
The learned and frequency arms use the same four POP entries and novel-edge position (fifth, alpha=400).
Percent difference = 100 * (first arm - second arm) / second arm; negative favours the first arm.
Primary: BetaTour 4+1 versus frequency 4+1, exact two-sided sign test on 40 instance pairs, ties omitted.
The three secondary overall sign tests receive Holm correction; subgroup rows are descriptive only.
Bootstrap intervals describe the mean paired percent difference and are not equivalent to sign-test p-values.
Practical superiority requires comparing against continuous POPMUSIC at the same total deadline.
The six common first tours, seed and instance are matched across restarted arms. First-trial costs are checked against continuous POP.
Common first phase plus arm-specific preparation and continuation count against each deadline. Drive writes and archive export do not.
Novel edge presence in an initial tour is a redundancy diagnostic, not proof of use during LKH search.
This holdout covers synthetic uniform and clustered 10k/20k instances; it does not establish effects on 1k, TSPLIB or evolved hard instances.
Incomplete data or first-trial mismatches suppress inferential statistics.

```
 group                                comparison class_of_comparison  instances  win  tie  loss  mean_delta_pct  median_delta_pct  ci95_low_pct  ci95_high_pct   sign_p  sign_p_holm_secondary
   all    BetaTour 4+1 / frequency 4+1 [primary]             primary         40   33    0     7       -0.006204         -0.005078     -0.008955      -0.003571 0.000042                    NaN
   all BetaTour 4+1 / continuous POP [practical]           secondary         40    8    0    32        0.007127          0.006579      0.004216       0.010026 0.000182               0.000546
   all             BetaTour 4+1 / restarted POP5           secondary         40   21    0    19       -0.002278         -0.001548     -0.006502       0.001663 0.874629               0.874629
   all            BetaTour 4+1 / fixed BetaTour3           secondary         40   15    0    25        0.003221          0.002978      0.000093       0.006263 0.153860               0.307720
clu10k    BetaTour 4+1 / frequency 4+1 [primary]             primary         12    9    0     3       -0.003580         -0.004743           NaN            NaN      NaN                    NaN
clu10k BetaTour 4+1 / continuous POP [practical]           secondary         12    2    0    10        0.007748          0.009646           NaN            NaN      NaN                    NaN
clu10k             BetaTour 4+1 / restarted POP5           secondary         12    2    0    10        0.004774          0.004409           NaN            NaN      NaN                    NaN
clu10k            BetaTour 4+1 / fixed BetaTour3           secondary         12    2    0    10        0.009090          0.007580           NaN            NaN      NaN                    NaN
clu20k    BetaTour 4+1 / frequency 4+1 [primary]             primary          8    8    0     0       -0.008438         -0.008570           NaN            NaN      NaN                    NaN
clu20k BetaTour 4+1 / continuous POP [practical]           secondary          8    1    0     7        0.005525          0.003690           NaN            NaN      NaN                    NaN
clu20k             BetaTour 4+1 / restarted POP5           secondary          8    6    0     2       -0.010025         -0.002953           NaN            NaN      NaN                    NaN
clu20k            BetaTour 4+1 / fixed BetaTour3           secondary          8    5    0     3       -0.002146         -0.003961           NaN            NaN      NaN                    NaN
uni10k    BetaTour 4+1 / frequency 4+1 [primary]             primary         12   10    0     2       -0.007264         -0.006448           NaN            NaN      NaN                    NaN
uni10k BetaTour 4+1 / continuous POP [practical]           secondary         12    3    0     9        0.004579          0.004938           NaN            NaN      NaN                    NaN
uni10k             BetaTour 4+1 / restarted POP5           secondary         12    8    0     4       -0.000015         -0.003718           NaN            NaN      NaN                    NaN
uni10k            BetaTour 4+1 / fixed BetaTour3           secondary         12    3    0     9        0.004587          0.007170           NaN            NaN      NaN                    NaN
uni20k    BetaTour 4+1 / frequency 4+1 [primary]             primary          8    6    0     2       -0.006317         -0.002104           NaN            NaN      NaN                    NaN
uni20k BetaTour 4+1 / continuous POP [practical]           secondary          8    2    0     6        0.011622          0.015943           NaN            NaN      NaN                    NaN
uni20k             BetaTour 4+1 / restarted POP5           secondary          8    5    0     3       -0.008502         -0.011473           NaN            NaN      NaN                    NaN
uni20k            BetaTour 4+1 / fixed BetaTour3           secondary          8    5    0     3       -0.002263         -0.004387           NaN            NaN      NaN                    NaN
```

Raw files: summary/per_instance.csv, summary/per_seed.csv, summary/candidate_diagnostics.csv.
Default ZIP includes stages/phase1.npz and candidates/*.npz for candidate-list auditing.