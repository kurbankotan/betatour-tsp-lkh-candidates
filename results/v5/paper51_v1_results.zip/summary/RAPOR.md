# BetaTour kontrollü Colab deneyi

51/51 mevcut makale örneği tamamlandı. Bu örnekler daha önce incelendiği için p değerleri keşifseldir.

İşaret: yüzde fark = 100 × (ilk kol − ikinci kol) / ikinci kol; negatif değer ilk kol lehine.
Birincil karşılaştırma BetaTour / eşit-5 POP yeniden başlatmadır. Diğer karşılaştırmalar keşifseldir.
Makaledeki aynı 51 örnek için, birincil satır dahil p değerlerini bağımsız doğrulama olarak yorumlamayın.
Güven aralığı örnek düzeyinde 5000 bootstrap tekrarından, p değeri iki yönlü işaret testinden gelir.
Holm sütunu rapordaki sekiz karşılaştırmayı birlikte düzeltir; kısmi çalışma p değerleri yalnız keşifseldir.
İlk aşama ortak kayıttan tekrar kullanıldı; uçtan uca olay zamanları her kolun kendi hazırlık ve devam süresiyle yeniden kuruldu.
Drive'a kontrol noktası yazma süresi algoritma süresine dahil değildir.
Ham POP yeniden başlatma aynı aday ID'lerini kullanır; dosya yazarı α değerlerini yeniden oluşturur ve sıfır ceza yazar.
Bu nedenle ham POP / kesintisiz POP farkı yalnız süreç yeniden başlatmasının saf etkisi değildir.
Süre eşlenmiş yeniden başlatma, eşit-5 POP kolunun devam olaylarını BetaTour'un ek hazırlık süresi kadar kaydırır.
Bu satır ölçülmüş yeni bir LKH kolu değil, duyarlılık analizidir.

```
 group                                        comparison  instances  win  tie  loss  mean_delta_pct  median_delta_pct  ci95_low_pct  ci95_high_pct  sign_p  sign_p_holm
   all BetaTour / eşit-5 POP yeniden başlatma [birincil]         51   26   18     7        -0.00529          -0.00004      -0.00781       -0.00289 0.00132      0.00923
   all                            BetaTour / tur sıklığı         51   22   19    10        -0.00183           0.00000      -0.00411        0.00048 0.05010      0.20041
   all         Ham POP yeniden başlatma / kesintisiz POP         51    7   18    26         0.00650           0.00003       0.00383        0.00956 0.00132      0.00923
   all             Eşit-5 POP / ham POP yeniden başlatma         51   19   20    12        -0.00048           0.00000      -0.00236        0.00162 0.28104      0.69808
   all                         BetaTour / kesintisiz POP         51   18   17    16         0.00073           0.00000      -0.00152        0.00308 0.86417      0.86417
   all               BetaTour / süre eşlenmiş eşit-5 POP         51   26   18     7        -0.00529          -0.00004      -0.00784       -0.00296 0.00132      0.00923
   all           BetaTour / eşit-5 POP, tohum ortalaması         51   44    3     4        -0.00937          -0.00560      -0.01464       -0.00490 0.00000      0.00000
   all          BetaTour / tur sıklığı, tohum ortalaması         51   27    6    18        -0.00316          -0.00030      -0.00559       -0.00089 0.23269      0.69808
clu10k BetaTour / eşit-5 POP yeniden başlatma [birincil]          8    6    0     2        -0.00235          -0.00245      -0.00578        0.00102 0.28906      1.00000
clu10k                            BetaTour / tur sıklığı          8    6    0     2        -0.00198          -0.00365      -0.00558        0.00249 0.28906      1.00000
clu10k         Ham POP yeniden başlatma / kesintisiz POP          8    2    0     6         0.00522           0.00235       0.00086        0.01026 0.28906      1.00000
clu10k             Eşit-5 POP / ham POP yeniden başlatma          8    7    0     1        -0.00373          -0.00446      -0.00561       -0.00179 0.07031      0.49219
clu10k                         BetaTour / kesintisiz POP          8    4    0     4        -0.00086          -0.00068      -0.00390        0.00213 1.00000      1.00000
clu10k               BetaTour / süre eşlenmiş eşit-5 POP          8    6    0     2        -0.00235          -0.00245      -0.00596        0.00083 0.28906      1.00000
clu10k           BetaTour / eşit-5 POP, tohum ortalaması          8    8    0     0        -0.00918          -0.00954      -0.01444       -0.00500 0.00781      0.06250
clu10k          BetaTour / tur sıklığı, tohum ortalaması          8    4    0     4        -0.00085          -0.00005      -0.00382        0.00202 1.00000      1.00000
 clu1k BetaTour / eşit-5 POP yeniden başlatma [birincil]          8    2    5     1        -0.00021           0.00000      -0.00129        0.00066 1.00000      1.00000
 clu1k                            BetaTour / tur sıklığı          8    1    6     1         0.00011           0.00000      -0.00036        0.00067 1.00000      1.00000
 clu1k         Ham POP yeniden başlatma / kesintisiz POP          8    1    7     0        -0.00044           0.00000      -0.00132        0.00000 1.00000      1.00000
 clu1k             Eşit-5 POP / ham POP yeniden başlatma          8    0    7     1         0.00043           0.00000       0.00000        0.00129 1.00000      1.00000
 clu1k                         BetaTour / kesintisiz POP          8    1    6     1        -0.00022           0.00000      -0.00133        0.00067 1.00000      1.00000
 clu1k               BetaTour / süre eşlenmiş eşit-5 POP          8    2    5     1        -0.00021           0.00000      -0.00129        0.00067 1.00000      1.00000
 clu1k           BetaTour / eşit-5 POP, tohum ortalaması          8    6    1     1        -0.00640          -0.00392      -0.02224        0.01347 0.12500      1.00000
 clu1k          BetaTour / tur sıklığı, tohum ortalaması          8    4    3     1        -0.00705          -0.00030      -0.01586        0.00006 0.37500      1.00000
clu20k BetaTour / eşit-5 POP yeniden başlatma [birincil]          4    4    0     0        -0.01058          -0.01112      -0.01621       -0.00494 0.12500      1.00000
clu20k                            BetaTour / tur sıklığı          4    2    0     2         0.00282          -0.00233      -0.01034        0.02111 1.00000      1.00000
clu20k         Ham POP yeniden başlatma / kesintisiz POP          4    0    0     4         0.01385           0.01253       0.00414        0.02487 0.12500      1.00000
clu20k             Eşit-5 POP / ham POP yeniden başlatma          4    1    0     3         0.00414           0.00188      -0.00136        0.01188 0.62500      1.00000
clu20k                         BetaTour / kesintisiz POP          4    2    0     2         0.00741           0.00229      -0.00308        0.02147 1.00000      1.00000
clu20k               BetaTour / süre eşlenmiş eşit-5 POP          4    4    0     0        -0.01058          -0.01112      -0.01621       -0.00494 0.12500      1.00000
clu20k           BetaTour / eşit-5 POP, tohum ortalaması          4    4    0     0        -0.00585          -0.00552      -0.01005       -0.00165 0.12500      1.00000
clu20k          BetaTour / tur sıklığı, tohum ortalaması          4    2    0     2         0.00324          -0.00078      -0.00359        0.01409 1.00000      1.00000
tsplib BetaTour / eşit-5 POP yeniden başlatma [birincil]         11    4    5     2        -0.00300           0.00000      -0.00723        0.00068 0.68750      1.00000
tsplib                            BetaTour / tur sıklığı         11    5    5     1        -0.00241           0.00000      -0.00659        0.00095 0.21875      1.00000
tsplib         Ham POP yeniden başlatma / kesintisiz POP         11    3    3     5         0.00489           0.00000       0.00039        0.01075 0.72656      1.00000
tsplib             Eşit-5 POP / ham POP yeniden başlatma         11    5    5     1        -0.00285           0.00000      -0.00639       -0.00005 0.21875      1.00000
tsplib                         BetaTour / kesintisiz POP         11    4    3     4        -0.00096           0.00000      -0.00759        0.00448 1.00000      1.00000
tsplib               BetaTour / süre eşlenmiş eşit-5 POP         11    4    5     2        -0.00300           0.00000      -0.00707        0.00059 0.68750      1.00000
tsplib           BetaTour / eşit-5 POP, tohum ortalaması         11    8    0     3        -0.01535          -0.00375      -0.03459       -0.00289 0.22656      1.00000
tsplib          BetaTour / tur sıklığı, tohum ortalaması         11    6    0     5        -0.00670          -0.00341      -0.01339       -0.00044 1.00000      1.00000
uni10k BetaTour / eşit-5 POP yeniden başlatma [birincil]          8    6    0     2        -0.00862          -0.01116      -0.01407       -0.00265 0.28906      1.00000
uni10k                            BetaTour / tur sıklığı          8    5    0     3        -0.00151          -0.00364      -0.00722        0.00426 0.72656      1.00000
uni10k         Ham POP yeniden başlatma / kesintisiz POP          8    1    0     7         0.01088           0.00922       0.00559        0.01642 0.07031      0.49219
uni10k             Eşit-5 POP / ham POP yeniden başlatma          8    4    0     4        -0.00149          -0.00121      -0.00757        0.00442 1.00000      1.00000
uni10k                         BetaTour / kesintisiz POP          8    5    0     3         0.00076          -0.00105      -0.00348        0.00493 0.72656      1.00000
uni10k               BetaTour / süre eşlenmiş eşit-5 POP          8    6    0     2        -0.00862          -0.01116      -0.01413       -0.00226 0.28906      1.00000
uni10k           BetaTour / eşit-5 POP, tohum ortalaması          8    8    0     0        -0.00850          -0.00675      -0.01283       -0.00446 0.00781      0.06250
uni10k          BetaTour / tur sıklığı, tohum ortalaması          8    5    0     3        -0.00212          -0.00129      -0.00599        0.00097 0.72656      1.00000
 uni1k BetaTour / eşit-5 POP yeniden başlatma [birincil]          8    0    8     0         0.00000           0.00000       0.00000        0.00000 1.00000      1.00000
 uni1k                            BetaTour / tur sıklığı          8    0    8     0         0.00000           0.00000       0.00000        0.00000 1.00000      1.00000
 uni1k         Ham POP yeniden başlatma / kesintisiz POP          8    0    8     0         0.00000           0.00000       0.00000        0.00000 1.00000      1.00000
 uni1k             Eşit-5 POP / ham POP yeniden başlatma          8    0    8     0         0.00000           0.00000       0.00000        0.00000 1.00000      1.00000
 uni1k                         BetaTour / kesintisiz POP          8    0    8     0         0.00000           0.00000       0.00000        0.00000 1.00000      1.00000
 uni1k               BetaTour / süre eşlenmiş eşit-5 POP          8    0    8     0         0.00000           0.00000       0.00000        0.00000 1.00000      1.00000
 uni1k           BetaTour / eşit-5 POP, tohum ortalaması          8    6    2     0        -0.00408          -0.00201      -0.00758       -0.00125 0.03125      0.25000
 uni1k          BetaTour / tur sıklığı, tohum ortalaması          8    4    3     1        -0.00107          -0.00037      -0.00267        0.00023 0.37500      1.00000
uni20k BetaTour / eşit-5 POP yeniden başlatma [birincil]          4    4    0     0        -0.02622          -0.02567      -0.03331       -0.01969 0.12500      1.00000
uni20k                            BetaTour / tur sıklığı          4    3    0     1        -0.01278          -0.01085      -0.02461       -0.00289 0.62500      1.00000
uni20k         Ham POP yeniden başlatma / kesintisiz POP          4    0    0     4         0.02421           0.02470       0.01110        0.03731 0.12500      1.00000
uni20k             Eşit-5 POP / ham POP yeniden başlatma          4    2    0     2         0.00722           0.00644      -0.00781        0.02225 1.00000      1.00000
uni20k                         BetaTour / kesintisiz POP          4    2    0     2         0.00519           0.00382      -0.00679        0.01854 1.00000      1.00000
uni20k               BetaTour / süre eşlenmiş eşit-5 POP          4    4    0     0        -0.02622          -0.02567      -0.03331       -0.01969 0.12500      1.00000
uni20k           BetaTour / eşit-5 POP, tohum ortalaması          4    4    0     0        -0.01509          -0.01303      -0.02124       -0.01005 0.12500      1.00000
uni20k          BetaTour / tur sıklığı, tohum ortalaması          4    2    0     2        -0.00294           0.00015      -0.01093        0.00327 1.00000      1.00000
```

Ham örnek ve tohum tabloları: summary/per_instance.csv, summary/per_seed.csv.
Aday listeleri candidates/ klasöründe, aşama kayıtları stages/ klasöründedir.