# BetaTour run v22: düzeltilmiş dosyalarla diğer boyutlar ve TSPLIB

43/43 örnek tamamlandı.

Yüzde fark = 100 x (ilk kol - ikinci kol) / ikinci kol; negatif değer ilk kolun daha kısa tur bulduğunu gösterir.
win/tie/loss: ilk kolun daha kısa, eşit, daha uzun olduğu örnek sayısı. Güven aralığı örnek düzeyinde 5000
bootstrap tekrarından, p değeri kesin iki yönlü işaret testinden gelir (eşitlikler sayılmaz).
best6: altı tohumun en iyisi. mean6: aynı tohumlu eşli yüzde farkların altı tohum ortalaması.
Birincil karşılaştırmalar (PROTOCOL_v22.md, koşudan önce yazıldı): P1 ve P2, mean6, bütçe sonunda, bütün
örnekler birlikte, ikisi birlikte Holm düzeltmeli. Diğer bütün satırlar ikincildir ve keşif amaçlıdır.
large: en az 7000 düğümlü örnekler; small: daha küçük örnekler.

## Birincil karşılaştırmalar

**P1 (mean6): BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC.** Anlamlı fark saptanmadı (bu, fark olmadığının kanıtı değildir; güven aralığına bakın). 26/4/13 (ilk kol kısa/eşit/uzun), ortalama fark %-0.0057 (%95 GA -0.0127 ile +0.0002), işaret testi p = 0.0533, Holm p = 0.1065

**P2 (mean6): Model / sayım.** Anlamlı fark saptanmadı (bu, fark olmadığının kanıtı değildir; güven aralığına bakın). 22/5/16 (ilk kol kısa/eşit/uzun), ortalama fark %-0.0008 (%95 GA -0.0034 ile +0.0015), işaret testi p = 0.4177, Holm p = 0.4177

## Bütçe sonunda bütün karşılaştırmalar (43 örnek birlikte)

```
key                                                       comparison endpoint  instances  win  tie  loss  mean_delta_pct  median_delta_pct  ci95_low_pct  ci95_high_pct  sign_p
 P1               BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    best6         43   18   17     8        -0.00151           0.00000      -0.00344        0.00023 0.07552
 P1               BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    mean6         43   26    4    13        -0.00570          -0.00116      -0.01274        0.00017 0.05325
 P2                                                    Model / sayım    best6         43   15   19     9        -0.00123           0.00000      -0.00348        0.00078 0.30746
 P2                                                    Model / sayım    mean6         43   22    5    16        -0.00084          -0.00004      -0.00338        0.00149 0.41769
 S1     Yeniden başlatmanın kendisi: LKH eşdeğeri dosya / kesintisiz    best6         43   15   19     9        -0.00116           0.00000      -0.00330        0.00074 0.30746
 S1     Yeniden başlatmanın kendisi: LKH eşdeğeri dosya / kesintisiz    mean6         43   18    5    20        -0.00149           0.00000      -0.00716        0.00229 0.87141
 S2 Listenin etkisi: BetaTour / POPMUSIC (ikisi de yeniden başlatma)    best6         43   15   19     9        -0.00034           0.00000      -0.00266        0.00220 0.30746
 S2 Listenin etkisi: BetaTour / POPMUSIC (ikisi de yeniden başlatma)    mean6         43   26    4    13        -0.00421          -0.00162      -0.00862       -0.00021 0.05325
 S3                                      Sayım / kesintisiz POPMUSIC    best6         43   15   17    11        -0.00027           0.00000      -0.00223        0.00196 0.55720
 S3                                      Sayım / kesintisiz POPMUSIC    mean6         43   26    4    13        -0.00486          -0.00128      -0.01307        0.00216 0.05325
 S4    Listenin etkisi: sayım / POPMUSIC (ikisi de yeniden başlatma)    best6         43   11   19    13         0.00089           0.00000      -0.00091        0.00280 0.83882
 S4    Listenin etkisi: sayım / POPMUSIC (ikisi de yeniden başlatma)    mean6         43   24    4    15        -0.00336          -0.00082      -0.00856        0.00166 0.19959
```

## Gruplara göre (P1 ve P2; mean6 ve best6)

```
 group key                                         comparison endpoint  instances  win  tie  loss  mean_delta_pct  median_delta_pct  ci95_low_pct  ci95_high_pct  sign_p
 large  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    best6         22   14    0     8        -0.00266          -0.00312      -0.00624        0.00066 0.28628
 large  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    mean6         22   13    0     9         0.00020          -0.00149      -0.00547        0.00651 0.52347
 large  P2                                      Model / sayım    best6         22   13    0     9        -0.00228          -0.00048      -0.00663        0.00186 0.52347
 large  P2                                      Model / sayım    mean6         22   15    0     7        -0.00173          -0.00093      -0.00604        0.00224 0.13380
 small  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    best6         21    4   17     0        -0.00030           0.00000      -0.00069       -0.00001 0.12500
 small  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    mean6         21   13    4     4        -0.01188          -0.00082      -0.02441       -0.00247 0.04904
 small  P2                                      Model / sayım    best6         21    2   19     0        -0.00014           0.00000      -0.00040        0.00000 0.50000
 small  P2                                      Model / sayım    mean6         21    7    5     9         0.00009           0.00000      -0.00217        0.00242 0.80362
 clu1k  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    best6          8    0    8     0         0.00000           0.00000       0.00000        0.00000 1.00000
 clu1k  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    mean6          8    2    3     3        -0.01221           0.00000      -0.03719        0.00061 1.00000
 clu1k  P2                                      Model / sayım    best6          8    1    7     0        -0.00006           0.00000      -0.00019        0.00000 1.00000
 clu1k  P2                                      Model / sayım    mean6          8    1    3     4        -0.00105           0.00024      -0.00504        0.00136 0.37500
clu20k  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    best6          8    4    0     4         0.00105           0.00210      -0.00398        0.00564 1.00000
clu20k  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    mean6          8    4    0     4         0.00779          -0.00044      -0.00285        0.02048 1.00000
clu20k  P2                                      Model / sayım    best6          8    5    0     3        -0.00544          -0.00281      -0.01370        0.00192 0.72656
clu20k  P2                                      Model / sayım    mean6          8    6    0     2        -0.00625          -0.00113      -0.01425       -0.00029 0.28906
tsplib  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    best6         11    8    3     0        -0.00570          -0.00252      -0.01110       -0.00172 0.00781
tsplib  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    mean6         11    9    0     2        -0.01464          -0.00504      -0.02990       -0.00381 0.06543
tsplib  P2                                      Model / sayım    best6         11    6    4     1        -0.00343          -0.00006      -0.00801       -0.00043 0.12500
tsplib  P2                                      Model / sayım    mean6         11    8    0     3        -0.00160          -0.00174      -0.00624        0.00321 0.22656
 uni1k  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    best6          8    2    6     0        -0.00047           0.00000      -0.00119        0.00000 0.50000
 uni1k  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    mean6          8    7    1     0        -0.00669          -0.00590      -0.01155       -0.00267 0.01562
 uni1k  P2                                      Model / sayım    best6          8    0    8     0         0.00000           0.00000       0.00000        0.00000 1.00000
 uni1k  P2                                      Model / sayım    mean6          8    4    2     2        -0.00063          -0.00038      -0.00289        0.00187 0.68750
uni20k  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    best6          8    4    0     4        -0.00086          -0.00003      -0.00459        0.00265 1.00000
uni20k  P1 BetaTour (düzeltilmiş dosya) / kesintisiz POPMUSIC    mean6          8    4    0     4         0.00060           0.00153      -0.00422        0.00521 1.00000
uni20k  P2                                      Model / sayım    best6          8    3    0     5         0.00359           0.00340      -0.00081        0.00842 0.72656
uni20k  P2                                      Model / sayım    mean6          8    3    0     5         0.00563           0.00604       0.00107        0.01071 0.72656
```

## Zaman içinde, büyük örnekler (bütçenin %25, %50, %75 ve %100'ünde; mean6)

```
key  time_pct  win  tie  loss  mean_delta_pct  ci95_low_pct  ci95_high_pct  sign_p
 P1        25    8    0    14        -0.00378      -0.01606        0.00598 0.28628
 P1        50   13    0     9        -0.00169      -0.00921        0.00503 0.52347
 P1        75   14    0     8         0.00113      -0.00474        0.00794 0.28628
 P1       100   13    0     9         0.00020      -0.00547        0.00651 0.52347
 P2        25    9    0    13        -0.00338      -0.01448        0.00539 0.52347
 P2        50   10    0    12        -0.00542      -0.01490        0.00114 0.83181
 P2        75   12    0    10        -0.00243      -0.00676        0.00180 0.83181
 P2       100   15    0     7        -0.00173      -0.00604        0.00224 0.13380
 S1        25    4    0    18         0.01627       0.00594        0.02802 0.00434
 S1        50    7    0    15         0.00502      -0.00058        0.01005 0.13380
 S1        75    5    0    17         0.00631       0.00288        0.01003 0.01690
 S1       100    6    0    16         0.00402       0.00160        0.00627 0.05248
 S2        25   18    0     4        -0.02001      -0.03396       -0.00881 0.00434
 S2        50   15    0     7        -0.00670      -0.01174       -0.00211 0.13380
 S2        75   15    0     7        -0.00518      -0.01068       -0.00018 0.13380
 S2       100   15    0     7        -0.00382      -0.00988        0.00230 0.13380
 S3        25   10    0    12        -0.00039      -0.00828        0.00801 0.83181
 S3        50    9    0    13         0.00374      -0.00546        0.01351 0.52347
 S3        75    9    0    13         0.00357      -0.00317        0.01287 0.52347
 S3       100   14    0     8         0.00193      -0.00417        0.01056 0.28628
 S4        25   18    0     4        -0.01661      -0.03083       -0.00663 0.00434
 S4        50   16    0     6        -0.00127      -0.00898        0.00909 0.05248
 S4        75   13    0     9        -0.00274      -0.00826        0.00387 0.52347
 S4       100   15    0     7        -0.00208      -0.00856        0.00616 0.13380
```

## Kollar: tamamlanan deneme sayısı, korunabilen kenar payı ve yeniden başlatmadan önce harcanan süre

```
 group        arm  instances  mean_trials_at_budget  trials_vs_pop_full_pct  kept_share  prelude_share_of_budget_pct  list_overhead_s
   all   pop_full         43               568.0930                  0.0000         NaN                       0.0000           0.0000
   all pop_native         43               539.6744                 -5.0025      0.7742                      11.0347           0.0000
   all  beta_tree         43               437.8178                -22.9320      0.7742                      11.8108           0.4141
   all  freq_tree         43               456.0736                -19.7185      0.7742                      11.3234           0.2503
 large   pop_full         22               377.8561                  0.0000         NaN                       0.0000           0.0000
 large pop_native         22               364.0000                 -3.6670      0.7706                       9.2097           0.0000
 large  beta_tree         22               318.6136                -15.6786      0.7706                       9.4491           0.7005
 large  freq_tree         22               327.8939                -13.2225      0.7706                       9.3614           0.4445
 small   pop_full         21               767.3889                  0.0000         NaN                       0.0000           0.0000
 small pop_native         21               723.7143                 -5.6913      0.7781                      12.9466           0.0000
 small  beta_tree         21               562.6984                -26.6736      0.7781                      14.2849           0.1141
 small  freq_tree         21               590.3571                -23.0694      0.7781                      13.3788           0.0468
 clu1k   pop_full          8               353.7292                  0.0000         NaN                       0.0000           0.0000
 clu1k pop_native          8               323.6250                 -8.5105      0.7460                      16.8047           0.0000
 clu1k  beta_tree          8               239.1250                -32.3988      0.7460                      18.4949           0.0845
 clu1k  freq_tree          8               261.8333                -25.9792      0.7460                      17.3326           0.0264
clu20k   pop_full          8               211.1667                  0.0000         NaN                       0.0000           0.0000
clu20k pop_native          8               206.0625                 -2.4171      0.7558                      10.8955           0.0000
clu20k  beta_tree          8               177.0625                -16.1504      0.7558                      11.1522           0.7703
clu20k  freq_tree          8               186.7083                -11.5825      0.7558                      11.0592           0.4913
tsplib   pop_full         11              1105.8182                  0.0000         NaN                       0.0000           0.0000
tsplib pop_native         11              1069.2727                 -3.3048      0.8353                       5.2196           0.0000
tsplib  beta_tree         11               859.1667                -22.3049      0.8353                       5.4315           0.3765
tsplib  freq_tree         11               896.6061                -18.9192      0.8353                       5.3403           0.2260
 uni1k   pop_full          8               694.6667                  0.0000         NaN                       0.0000           0.0000
 uni1k pop_native          8               631.2708                 -9.1261      0.7547                      14.5046           0.0000
 uni1k  beta_tree          8               526.1042                -24.2652      0.7547                      16.1810           0.0838
 uni1k  freq_tree          8               531.8542                -23.4375      0.7547                      15.0352           0.0265
uni20k   pop_full          8               273.4375                  0.0000         NaN                       0.0000           0.0000
uni20k pop_native          8               269.5417                 -1.4248      0.7566                       9.9298           0.0000
uni20k  beta_tree          8               229.6250                -16.0229      0.7566                      10.1863           0.7696
uni20k  freq_tree          8               238.1667                -12.8990      0.7566                      10.0932           0.4902
```

## TSPLIB: bilinen en iyi tura göre fark (%, best6)

```
instance     n  budget_s  pop_full_gap_pct  pop_native_gap_pct  beta_tree_gap_pct  freq_tree_gap_pct
 pcb3038  3038     60.76            0.0000              0.0000             0.0000             0.0000
  fl3795  3795     75.90            0.0000              0.0000             0.0000             0.0000
 fnl4461  4461     89.22            0.0000              0.0000             0.0000             0.0000
  rl5915  5915    118.30            0.0025              0.0025             0.0000             0.0025
  rl5934  5934    118.68            0.0002              0.0002             0.0000             0.0000
 pla7397  7397    147.94            0.0111              0.0090             0.0039             0.0111
 rl11849 11849    236.98            0.0409              0.0343             0.0130             0.0367
usa13509 13509    270.18            0.0039              0.0085             0.0013             0.0040
brd14051 14051    281.02            0.0213              0.0158             0.0168             0.0190
  d15112 15112    302.24            0.0352              0.0285             0.0209             0.0210
  d18512 18512    370.24            0.0236              0.0299             0.0198             0.0194
```

Ham tablolar: summary/per_instance.csv, per_seed.csv, paired_stats.csv (bütün zaman noktaları), arms.csv.
Aday dosyaları candidates/, ilk aşama dizileri stages/<örnek>/phase1.npz içindedir.