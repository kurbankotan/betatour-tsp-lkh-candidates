# BetaTour güven uyarlamalı aday listesi deneyi

40/40 yeni sentetik örnek tamamlandı. Birincil karşılaştırma uyarlamalı / sabit BetaTour'dur.

Yüzde fark = 100 × (ilk kol − ikinci kol) / ikinci kol; negatif fark ilk kol lehine.
Birincil karşılaştırma uyarlamalı / sabit BetaTour'dur; tam 40 örnek için iki yönlü kesin işaret testi ve p < 0.05 eşiği önceden belirlendi.
Güven kuralı: alt çeyrekte 2, orta yarıda 3, üst çeyrekte 4 model adayı; POPMUSIC ile beşe tamamla.
Aynı ağ ağırlıkları, ilk turlar, altı LKH tohumu, beş aday ve dış aday dosyası biçimi kullanılır.
Diğer karşılaştırmalar ve alt gruplar keşifseldir; Holm sütunu sekiz genel karşılaştırmayı düzeltir.
Güven aralığı örnek düzeyinde 5000 bootstrap tekrarından, p değeri iki yönlü işaret testinden gelir.
Eksik örneklerde veya ilk turlar eşleşmezse çıkarımsal p değeri üretilmez.
Ortak ilk aşama ve her kolun hazırlık/devam süresi çizelgeye katılır; Drive kayıt süresi dışarıdadır.
Ham POP / kesintisiz POP farkı aday dosyası ve cezalar da değiştiği için saf yeniden başlatma etkisi değildir.

```
 group                                comparison  instances  win  tie  loss  mean_delta_pct  median_delta_pct  ci95_low_pct  ci95_high_pct  sign_p  sign_p_holm
   all    Uyarlamalı / sabit BetaTour [birincil]         40   12   14    14        -0.00008           0.00000      -0.00262        0.00243 0.84502      1.00000
   all                   Uyarlamalı / eşit-5 POP         40   20   14     6        -0.00539          -0.00028      -0.00845       -0.00260 0.00936      0.07484
   all                  Uyarlamalı / tur sıklığı         40   13   14    13        -0.00100           0.00000      -0.00338        0.00114 1.00000      1.00000
   all               Uyarlamalı / kesintisiz POP         40   12   15    13         0.00240           0.00000      -0.00054        0.00565 1.00000      1.00000
   all               Sabit BetaTour / eşit-5 POP         40   17   15     8        -0.00531           0.00000      -0.00880       -0.00182 0.10775      0.64651
   all              Sabit BetaTour / tur sıklığı         40   15   15    10        -0.00092           0.00000      -0.00367        0.00200 0.42436      1.00000
   all           Sabit BetaTour / kesintisiz POP         40   11   14    15         0.00248           0.00000      -0.00072        0.00588 0.55720      1.00000
   all Ham POP yeniden başlatma / kesintisiz POP         40    7   13    20         0.00703           0.00093       0.00367        0.01068 0.01916      0.13410
clu10k    Uyarlamalı / sabit BetaTour [birincil]          8    3    0     5         0.00083           0.00272           NaN            NaN     NaN          NaN
clu10k                   Uyarlamalı / eşit-5 POP          8    7    0     1        -0.00872          -0.00739           NaN            NaN     NaN          NaN
clu10k                  Uyarlamalı / tur sıklığı          8    3    0     5        -0.00021           0.00071           NaN            NaN     NaN          NaN
clu10k               Uyarlamalı / kesintisiz POP          8    4    0     4         0.00158           0.00077           NaN            NaN     NaN          NaN
clu10k               Sabit BetaTour / eşit-5 POP          8    6    0     2        -0.00955          -0.00781           NaN            NaN     NaN          NaN
clu10k              Sabit BetaTour / tur sıklığı          8    5    0     3        -0.00104          -0.00253           NaN            NaN     NaN          NaN
clu10k           Sabit BetaTour / kesintisiz POP          8    3    0     5         0.00075           0.00071           NaN            NaN     NaN          NaN
clu10k Ham POP yeniden başlatma / kesintisiz POP          8    3    0     5         0.00511           0.00493           NaN            NaN     NaN          NaN
 clu1k    Uyarlamalı / sabit BetaTour [birincil]          8    1    7     0        -0.00330           0.00000           NaN            NaN     NaN          NaN
 clu1k                   Uyarlamalı / eşit-5 POP          8    0    7     1         0.00031           0.00000           NaN            NaN     NaN          NaN
 clu1k                  Uyarlamalı / tur sıklığı          8    0    7     1         0.00031           0.00000           NaN            NaN     NaN          NaN
 clu1k               Uyarlamalı / kesintisiz POP          8    0    7     1         0.00031           0.00000           NaN            NaN     NaN          NaN
 clu1k               Sabit BetaTour / eşit-5 POP          8    0    7     1         0.00361           0.00000           NaN            NaN     NaN          NaN
 clu1k              Sabit BetaTour / tur sıklığı          8    0    7     1         0.00361           0.00000           NaN            NaN     NaN          NaN
 clu1k           Sabit BetaTour / kesintisiz POP          8    0    7     1         0.00361           0.00000           NaN            NaN     NaN          NaN
 clu1k Ham POP yeniden başlatma / kesintisiz POP          8    0    7     1         0.00177           0.00000           NaN            NaN     NaN          NaN
clu20k    Uyarlamalı / sabit BetaTour [birincil]          4    4    0     0        -0.00827          -0.00834           NaN            NaN     NaN          NaN
clu20k                   Uyarlamalı / eşit-5 POP          4    4    0     0        -0.01472          -0.01634           NaN            NaN     NaN          NaN
clu20k                  Uyarlamalı / tur sıklığı          4    3    0     1        -0.01045          -0.00677           NaN            NaN     NaN          NaN
clu20k               Uyarlamalı / kesintisiz POP          4    2    0     2         0.00661           0.00672           NaN            NaN     NaN          NaN
clu20k               Sabit BetaTour / eşit-5 POP          4    3    0     1        -0.00646          -0.00922           NaN            NaN     NaN          NaN
clu20k              Sabit BetaTour / tur sıklığı          4    1    0     3        -0.00218           0.00299           NaN            NaN     NaN          NaN
clu20k           Sabit BetaTour / kesintisiz POP          4    0    0     4         0.01488           0.01421           NaN            NaN     NaN          NaN
clu20k Ham POP yeniden başlatma / kesintisiz POP          4    0    0     4         0.02179           0.02211           NaN            NaN     NaN          NaN
uni10k    Uyarlamalı / sabit BetaTour [birincil]          8    2    0     6         0.00374           0.00301           NaN            NaN     NaN          NaN
uni10k                   Uyarlamalı / eşit-5 POP          8    5    0     3        -0.00462          -0.00570           NaN            NaN     NaN          NaN
uni10k                  Uyarlamalı / tur sıklığı          8    5    0     3        -0.00011          -0.00035           NaN            NaN     NaN          NaN
uni10k               Uyarlamalı / kesintisiz POP          8    6    0     2        -0.00422          -0.00806           NaN            NaN     NaN          NaN
uni10k               Sabit BetaTour / eşit-5 POP          8    5    0     3        -0.00836          -0.01200           NaN            NaN     NaN          NaN
uni10k              Sabit BetaTour / tur sıklığı          8    6    0     2        -0.00385          -0.00147           NaN            NaN     NaN          NaN
uni10k           Sabit BetaTour / kesintisiz POP          8    7    0     1        -0.00796          -0.00755           NaN            NaN     NaN          NaN
uni10k Ham POP yeniden başlatma / kesintisiz POP          8    3    0     5         0.00325           0.00198           NaN            NaN     NaN          NaN
 uni1k    Uyarlamalı / sabit BetaTour [birincil]          8    0    7     1         0.00021           0.00000           NaN            NaN     NaN          NaN
 uni1k                   Uyarlamalı / eşit-5 POP          8    0    7     1         0.00021           0.00000           NaN            NaN     NaN          NaN
 uni1k                  Uyarlamalı / tur sıklığı          8    0    7     1         0.00021           0.00000           NaN            NaN     NaN          NaN
 uni1k               Uyarlamalı / kesintisiz POP          8    0    8     0         0.00000           0.00000           NaN            NaN     NaN          NaN
 uni1k               Sabit BetaTour / eşit-5 POP          8    0    8     0         0.00000           0.00000           NaN            NaN     NaN          NaN
 uni1k              Sabit BetaTour / tur sıklığı          8    0    8     0         0.00000           0.00000           NaN            NaN     NaN          NaN
 uni1k           Sabit BetaTour / kesintisiz POP          8    1    7     0        -0.00021           0.00000           NaN            NaN     NaN          NaN
 uni1k Ham POP yeniden başlatma / kesintisiz POP          8    1    6     1         0.00156           0.00000           NaN            NaN     NaN          NaN
uni20k    Uyarlamalı / sabit BetaTour [birincil]          4    2    0     2         0.00453           0.00067           NaN            NaN     NaN          NaN
uni20k                   Uyarlamalı / eşit-5 POP          4    4    0     0        -0.01355          -0.00946           NaN            NaN     NaN          NaN
uni20k                  Uyarlamalı / tur sıklığı          4    2    0     2         0.00005          -0.00164           NaN            NaN     NaN          NaN
uni20k               Uyarlamalı / kesintisiz POP          4    0    0     4         0.02209           0.01908           NaN            NaN     NaN          NaN
uni20k               Sabit BetaTour / eşit-5 POP          4    3    0     1        -0.01808          -0.02235           NaN            NaN     NaN          NaN
uni20k              Sabit BetaTour / tur sıklığı          4    3    0     1        -0.00448          -0.00646           NaN            NaN     NaN          NaN
uni20k           Sabit BetaTour / kesintisiz POP          4    0    0     4         0.01756           0.01671           NaN            NaN     NaN          NaN
uni20k Ham POP yeniden başlatma / kesintisiz POP          4    0    0     4         0.02513           0.02036           NaN            NaN     NaN          NaN
```

Ham örnek ve tohum tabloları: summary/per_instance.csv, summary/per_seed.csv.
Aday listeleri ve büyük aşama kayıtları Drive'daki candidates/ ve stages/ klasörlerindedir; varsayılan ZIP bunların .npz dosyalarını içermez.